import os

class Config:
    SECRET_KEY = os.environ.get('SECRET_KEY') or 'dev-secret-key-change-in-production'
    SQLALCHEMY_DATABASE_URI = 'sqlite:///sales.db'  # Change to MySQL: 'mysql://user:pass@localhost/sales_db'
    SQLALCHEMY_TRACK_MODIFICATIONS = False