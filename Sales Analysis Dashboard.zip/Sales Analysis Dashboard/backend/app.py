from flask import Flask
from flask_cors import CORS
from config import Config
from models import db
from routes import routes

app = Flask(__name__)
app.config.from_object(Config)
db.init_app(app)
CORS(app)
app.register_blueprint(routes)

if __name__ == '__main__':
    with app.app_context():
        db.create_all()
        # Add a default user if not exists
        from models import User, Sale
        from werkzeug.security import generate_password_hash
        from datetime import date
        if not User.query.filter_by(username='admin').first():
            admin = User(username='admin', password_hash=generate_password_hash('password'), role='admin')
            db.session.add(admin)
            db.session.commit()
        # Add sample data
        if Sale.query.count() == 0:
            sales = [
                Sale(product_name='Laptop', category='Electronics', amount=1200.00, quantity=1, region='North', date=date(2023, 1, 15), customer='John Doe'),
                Sale(product_name='Mouse', category='Electronics', amount=25.00, quantity=2, region='South', date=date(2023, 2, 10), customer='Jane Smith'),
                Sale(product_name='Keyboard', category='Electronics', amount=75.00, quantity=1, region='East', date=date(2023, 3, 5), customer='Bob Johnson'),
                Sale(product_name='Monitor', category='Electronics', amount=300.00, quantity=1, region='West', date=date(2023, 4, 20), customer='Alice Brown'),
                Sale(product_name='Chair', category='Furniture', amount=150.00, quantity=1, region='North', date=date(2023, 5, 12), customer='Charlie Wilson'),
                Sale(product_name='Desk', category='Furniture', amount=250.00, quantity=1, region='South', date=date(2023, 6, 8), customer='Diana Davis'),
                Sale(product_name='Laptop', category='Electronics', amount=1100.00, quantity=1, region='East', date=date(2023, 7, 15), customer='Eve Garcia'),
                Sale(product_name='Mouse', category='Electronics', amount=20.00, quantity=3, region='West', date=date(2023, 8, 22), customer='Frank Miller'),
                Sale(product_name='Headphones', category='Electronics', amount=100.00, quantity=1, region='North', date=date(2023, 9, 10), customer='Grace Lee'),
                Sale(product_name='Webcam', category='Electronics', amount=80.00, quantity=1, region='South', date=date(2023, 10, 5), customer='Henry Taylor'),
            ]
            for sale in sales:
                db.session.add(sale)
            db.session.commit()
    app.run(debug=True)