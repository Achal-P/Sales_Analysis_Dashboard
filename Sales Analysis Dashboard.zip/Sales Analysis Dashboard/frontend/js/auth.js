// Firebase Configuration
const firebaseConfig = {
  apiKey: "AIzaSyD9I6jWVvD-LuNIqMsmVTjlX8piXku-Q8s",
  authDomain: "sales-analysis-dashboard-6cd0c.firebaseapp.com",
  projectId: "sales-analysis-dashboard-6cd0c",
  storageBucket: "sales-analysis-dashboard-6cd0c.firebasestorage.app",
  messagingSenderId: "670846720070",
  appId: "1:670846720070:web:a58934bf83951f694d1247",
  measurementId: "G-E7CHZ3DD0S"
};

// Initialize Firebase
firebase.initializeApp(firebaseConfig);
const auth = firebase.auth();
const db = firebase.firestore();

console.log('Firebase initialized', !!firebase, !!auth, !!db);

// Auth State Management
let currentUser = null;

auth.onAuthStateChanged((user) => {
  currentUser = user;
  updateUI();
});

// Update UI based on auth state
function updateUI() {
  const loginContainer = document.getElementById('login-container');
  const dashboardContainer = document.getElementById('dashboard-container');
  
  if (currentUser) {
    if (loginContainer) loginContainer.style.display = 'none';
    if (dashboardContainer) dashboardContainer.style.display = 'flex';
    if (document.getElementById('user-email')) {
      document.getElementById('user-email').textContent = currentUser.email;
    }
    loadSales();
  } else {
    if (loginContainer) loginContainer.style.display = 'flex';
    if (dashboardContainer) dashboardContainer.style.display = 'none';
  }
}

// Login
async function loginUser(email, password) {
  try {
    const result = await auth.signInWithEmailAndPassword(email, password);
    return { success: true, user: result.user };
  } catch (error) {
    return { success: false, error: error.message };
  }
}

// Register
async function registerUser(email, password, displayName) {
  try {
    const result = await auth.createUserWithEmailAndPassword(email, password);
    await result.user.updateProfile({ displayName });
    
    // Store user data in Firestore
    await db.collection('users').doc(result.user.uid).set({
      email: email,
      displayName: displayName,
      createdAt: new Date(),
      role: 'user'
    });
    
    return { success: true, user: result.user };
  } catch (error) {
    return { success: false, error: error.message };
  }
}

// Logout
async function logoutUser() {
  try {
    await auth.signOut();
    return { success: true };
  } catch (error) {
    return { success: false, error: error.message };
  }
}

// Get current user
function getCurrentUser() {
  return currentUser;
}

// Check if user is authenticated
function isAuthenticated() {
  return currentUser !== null;
}
