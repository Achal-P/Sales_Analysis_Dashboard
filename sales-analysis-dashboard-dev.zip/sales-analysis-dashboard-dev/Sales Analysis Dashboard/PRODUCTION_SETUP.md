# 🚀 Sales Analysis Dashboard - Production Setup Guide

## Overview
Professional Sales Analysis Dashboard with Real-time Analytics, Firebase Integration, and Employee Management.

**Version:** 2.0 (Production-Ready)  
**Last Updated:** April 2026

---

## ✨ Features

### Dashboard
- 📊 Real-time KPI metrics (Total Sales, Orders, Average Order Value, Growth Rate)
- 📈 Advanced analytics with interactive charts (Revenue Trend, Top Products, Regional Sales, Customer Activity)
- 🎯 Regional sales breakdown
- 🔄 Auto-refresh data synchronization

### Sales Management
- ✅ Add/Edit/Delete sales records
- 🏷️ Category and region filtering
- 📋 Detailed sales table with search and export
- 📅 Date tracking and customer information
- 🔐 User-specific data isolation (Firestore)

### User Management
- 👤 Customer directory with contact management
- 🤝 Provider/Supplier tracking
- 🔐 Role-based access control
- 📧 Email notifications

### Analytics & Reporting
- 📊 Multiple chart types (Line, Pie, Bar graphs)
- 🔍 Advanced filtering and search
- 💾 Data export capabilities
- 📈 Trend analysis and forecasting

### UI/UX
- 🌓 Dark Mode toggle
- 📱 Fully responsive design (Mobile, Tablet, Desktop)
- ⚡ Smooth animations and transitions
- 🎨 Modern, professional design system

---

## 🛠️ Tech Stack

### Frontend
- HTML5 / CSS3 / JavaScript (ES6+)
- Firebase Authentication & Firestore Database
- Chart.js for data visualization
- Responsive CSS Grid & Flexbox
- Modern browser support (Chrome, Firefox, Safari, Edge)

### Backend
- Python 3.14+
- Flask 2.3.3
- Flask-SQLAlchemy 3.0.5
- Firebase SDK (compat)
- RESTful API

### Database
- SQLite (Local Development)
- Cloud Firestore (Production)

### Hosting
- Python HTTP Server (Development)
- Docker/Gunicorn (Production)

---

## 📋 System Requirements

- **Python:** 3.10 or higher
- **Node.js/NPM:** Optional (for build tools)
- **Browser:** Modern browser with JavaScript enabled
- **Internet:** For Firebase connectivity
- **Storage:** 100MB+ for application and data

---

## 🚀 Quick Start (Development)

### 1. Clone / Setup Repository
```bash
cd "d:\Sales_Analysis_Dashboard-main\Sales Analysis Dashboard\Sales Analysis Dashboard"
```

### 2. Install Python Dependencies
```bash
cd backend
pip install -r requirements.txt
```

### 3. Start Backend Server
**Terminal 1 - Flask Backend (API)**
```bash
cd backend
python app.py
```
✅ Backend runs on: **http://localhost:5000**

### 4. Start Frontend Server
**Terminal 2 - Frontend (UI)**
```bash
cd frontend
python -m http.server 8080
```
✅ Frontend runs on: **http://localhost:8080**

### 5. Access Application
Open your browser and go to:
```
http://localhost:8080/index.html
```

---

## 🔐 Firestore Rules (Copy to Firebase Console)

```javascript
rules_version = '2';
service cloud.firestore {
  match /databases/{database}/documents {
    match /users/{uid} {
      allow read, write: if request.auth.uid == uid;
 
      match /sales/{document=**} {
        allow read, write: if request.auth.uid == uid;
      }

      match /customers/{document=**} {
        allow read, write: if request.auth.uid == uid;
      }

      match /providers/{document=**} {
        allow read, write: if request.auth.uid == uid;
      }
    }
  }
}
```

---

## 🔑 Firebase Credentials

Your Firebase project is already configured. Current credentials:
```javascript
const firebaseConfig = {
  apiKey: "AIzaSyAJGExoDwXtQyWAumazNtBDP6mc5rmfACk",
  authDomain: "sales-analysis-dashboard-f7dab.firebaseapp.com",
  projectId: "sales-analysis-dashboard-f7dab",
  storageBucket: "sales-analysis-dashboard-f7dab.firebasestorage.app",
  messagingSenderId: "660175278485",
  appId: "1:660175278485:web:215a38e369a5ad4dc1269c",
  measurementId: "G-B2MRE44W69"
};
```

---

## 📦 Production Deployment

### Option 1: Using Gunicorn + Nginx

**1. Install Gunicorn:**
```bash
pip install gunicorn
```

**2. Install Nginx:** (Windows PowerShell)
```powershell
choco install nginx  # or download from nginx.org
```

**3. Run Backend with Gunicorn:**
```bash
cd backend
gunicorn -w 4 -b 0.0.0.0:5000 app:app
```

**4. Configure Nginx:**
```nginx
server {
    listen 80;
    server_name your-domain.com;

    location /api {
        proxy_pass http://127.0.0.1:5000;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
    }

    location / {
        root /path/to/frontend;
        try_files $uri $uri/ /index.html;
    }
}
```

### Option 2: Docker Containerization

**1. Create Dockerfile:**
```dockerfile
FROM python:3.14-slim

WORKDIR /app

COPY backend/requirements.txt .
RUN pip install -r requirements.txt

COPY backend/ .

CMD ["gunicorn", "-w", "4", "-b", "0.0.0.0:5000", "app:app"]

EXPOSE 5000
```

**2. Build and Run:**
```bash
docker build -t sales-dashboard .
docker run -p 5000:5000 -e FLASK_ENV=production sales-dashboard
```

### Option 3: Cloud Deployment (Heroku, AWS, Google Cloud)

**Deploy to Heroku:**
```bash
heroku login
heroku create your-app-name
git push heroku main
```

---

## 🔍 Environment Variables

Create `.env` file in root directory:
```env
FLASK_ENV=production
FLASK_DEBUG=False
SECRET_KEY=your-secure-secret-key
DATABASE_URL=sqlite:///sales.db
CORS_ORIGINS=https://yourdomain.com
```

---

## 📊 API Endpoints

### Authentication
- `POST /api/login` - User login
- `POST /api/logout` - User logout
- `POST /api/register` - User registration

### Sales Management
- `GET /api/sales` - Get all sales
- `POST /api/sales` - Create new sale
- `PUT /api/sales/<id>` - Update sale
- `DELETE /api/sales/<id>` - Delete sale

### Analytics
- `GET /api/sales/analytics/summary` - Get summary metrics
- `GET /api/sales/analytics/trends` - Get trend data
- `GET /api/sales/analytics/regions` - Regional analysis

---

## 🎯 Performance Optimization

### Frontend Optimization
- ✅ Minify CSS/JavaScript
- ✅ Enable gzip compression
- ✅ Implement lazy loading
- ✅ Cache-busting for assets
- ✅ CDN for static files

### Backend Optimization
- ✅ Database indexing
- ✅ Connection pooling
- ✅ Response caching
- ✅ Rate limiting
- ✅ Async task queues (Celery)

### Recommended Tools
```bash
# Frontend optimization
npm install -D webpack webpack-cli terser-webpack-plugin

# Backend monitoring
pip install prometheus-flask-exporter
pip install python-dotenv
```

---

## 🔒 Security Best Practices

### Implemented
- ✅ Firebase Authentication
- ✅ CORS enabled (all origins for now)
- ✅ Firestore Security Rules
- ✅ Session management
- ✅ Password hashing (Werkzeug)

### Recommendations for Production
1. **HTTPS Only** - Enforce SSL/TLS certificates
2. **API Rate Limiting** - Limit requests per IP/user
3. **CORS Restriction** - Whitelist only trusted domains
4. **API Key Management** - Store keys in secure vault
5. **Regular Backups** - Auto-backup Firestore data
6. **Logging & Monitoring** - Implement error tracking
7. **SQL Injection Prevention** - Use parameterized queries (already done)
8. **XSS Protection** - Sanitize user inputs
9. **CSRF Protection** - Implement CSRF tokens

### Example Production CORS:
```python
CORS(app, resources={
    r"/api/*": {
        "origins": ["https://yourdomain.com", "https://www.yourdomain.com"],
        "methods": ["GET", "POST", "PUT", "DELETE"],
        "allow_headers": ["Content-Type", "Authorization"]
    }
})
```

---

## 📝 Configuration Files

### Backend Configuration (`backend/config.py`)
```python
import os

class Config:
    SQLALCHEMY_DATABASE_URI = os.environ.get('DATABASE_URL') or 'sqlite:///sales.db'
    SQLALCHEMY_TRACK_MODIFICATIONS = False
    SECRET_KEY = os.environ.get('SECRET_KEY') or 'dev-secret-key'
    SESSION_COOKIE_SECURE = True
    SESSION_COOKIE_HTTPONLY = True
    PERMANENT_SESSION_LIFETIME = 3600

class DevelopmentConfig(Config):
    DEBUG = True

class ProductionConfig(Config):
    DEBUG = False
```

---

## 🐛 Troubleshooting

### Issue: "ModuleNotFoundError: No module named 'flask'"
**Solution:**
```bash
pip install -r backend/requirements.txt
```

### Issue: "Connection refused on localhost:5000"
**Solution:**
- Ensure Flask backend is running: `python backend/app.py`
- Check if port 5000 is available

### Issue: "Firebase authentication fails"
**Solution:**
- Verify Firebase credentials in `frontend/js/auth.js`
- Check Firestore security rules
- Ensure internet connection

### Issue: "CORS errors in console"
**Solution:**
- Verify CORS is enabled in `backend/app.py`
- Check allowed origins match your frontend URL

---

## 📚 Documentation

### User Guide
1. **Login/Register** - Create account with email
2. **Dashboard** - View KPIs and charts
3. **Add Sales** - Use form to record sales
4. **Manage Customers** - Add/edit customer info
5. **View Reports** - Analyze business metrics
6. **Export Data** - Download sales data

### Developer Guide
- API documentation in `/docs/API.md`
- Database schema in `/docs/SCHEMA.md`
- Deployment guide in `/docs/DEPLOY.md`

---

## 📞 Support & Contact

For issues, feature requests, or questions:
- 📧 Email: support@yourdomain.com
- 💬 Discord: [Your Discord]
- 🐛 Issues: GitHub Issues
- 📖 Docs: [Your Documentation]

---

## 📄 License

This project is licensed under the MIT License - see LICENSE file for details.

---

## 🎉 Getting Help

### Common Commands

**Development Mode:**
```bash
# Terminal 1
cd backend && python app.py

# Terminal 2
cd frontend && python -m http.server 8080
```

**Production Mode:**
```bash
# Terminal 1
cd backend && gunicorn -w 4 -b 0.0.0.0:5000 app:app

# Terminal 2
# Serve frontend with Nginx or web server
```

**Database Reset:**
```bash
cd backend
python -c "from app import app, db; app.app_context().push(); db.create_all(); print('Database initialized')"
```

---

**Version 2.0 - April 2026 - Ready for Production! 🚀**
