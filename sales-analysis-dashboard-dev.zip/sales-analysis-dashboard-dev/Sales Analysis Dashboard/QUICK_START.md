# 🚀 ESDS Sales Dashboard - Quick Start Commands

## ⚡ Fastest Way to Start

### Open Terminal in VS Code and Run These Commands (One per Terminal)

**Terminal 1 - Backend:**
```bash
cd backend
python app.py
```

**Terminal 2 - Frontend:**
```bash
cd frontend
python -m http.server 8080
```

**Then Open Browser:**
```
http://localhost:8080/index.html
```

---

## Manual Setup (All Platforms)

### Step 1: Install Dependencies
```bash
cd backend
pip install -r requirements.txt
cd ..
```

### Step 2: Start Backend (Terminal 1)
```bash
cd backend
python app.py
```
✅ Backend runs on: **http://localhost:5000**

### Step 3: Start Frontend (Terminal 2)
```bash
cd frontend
python -m http.server 8080
```
✅ Frontend runs on: **http://localhost:8080**

### Step 4: Open in Browser
```
http://localhost:8080/index.html
```

---

## 🔐 First Time Setup

1. **Sign Up** - Create an account with email/password
2. **Verify Email** - Check your email for verification
3. **Login** - Use your credentials to login
4. **Explore Dashboard** - View sample data and charts
5. **Add Sales** - Click "+ Add Sale" to create records

---

## 📱 Key Features to Try

- **Dashboard**: View real-time metrics and charts
- **Add Sales**: Use the form to record new sales
- **Filter Data**: Filter by category, region, date
- **Dark Mode**: Toggle 🌙 for dark mode
- **Analytics**: View detailed reports and trends

---

## 🛠️ Useful Commands

### Reset Database
```bash
cd backend
python -c "from app import app, db; app.app_context().push(); db.drop_all(); db.create_all(); print('Reset complete')"
```

### Check Backend Health
```bash
curl http://localhost:5000/health
```

### View API Info
```bash
curl http://localhost:5000/api/info
```

### Production Mode
```bash
pip install gunicorn
cd backend
gunicorn -w 4 -b 0.0.0.0:5000 app:app
```

---

## ✨ What's New (v2.0)

- ✅ Professional UI with enhanced design
- ✅ Advanced analytics and charts
- ✅ Firestore integration (cloud database)
- ✅ Dark mode support
- ✅ Responsive mobile design
- ✅ Production-ready configuration
- ✅ Security headers and error handling
- ✅ Health check endpoints
- ✅ Comprehensive API documentation
- ✅ Docker support

---

## 🆘 Troubleshooting

### Issue: "Address already in use"
```bash
# Kill Python process
# Windows:
taskkill /F /IM python.exe
# Linux/Mac:
pkill -f python
```

### Issue: "Module not found"
```bash
pip install -r backend/requirements.txt
```

### Issue: "Port 8080 already in use"
```bash
python -m http.server 9000  # Use different port
```

### Issue: "Firebase authentication fails"
- Check internet connection
- Verify Firebase project is active
- Check credentials in `frontend/js/auth.js`

---

## 📊 Sample Data Access

**Default Admin Account:**
- Email: admin
- Password: password (for local development only)

---

## 🌐 Browser Support

- ✅ Chrome/Edge (Chromium)
- ✅ Firefox
- ✅ Safari
- ✅ Mobile browsers (iOS Safari, Chrome Mobile)

---

## 📞 Need Help?

1. Check **PRODUCTION_SETUP.md** for detailed documentation
2. Review API endpoints in docs
3. Check console for errors (F12)
4. Verify backend is running (http://localhost:5000/health)

---

## 🎯 Next Steps

1. ✅ Get the app running (you're here!)
2. ⬜ Customize with your company branding
3. ⬜ Add your team members
4. ⬜ Configure Firestore rules per your needs
5. ⬜ Deploy to production

---

**Happy selling! 🎉**
