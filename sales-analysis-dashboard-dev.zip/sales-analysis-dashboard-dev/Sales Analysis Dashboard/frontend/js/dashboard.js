// Dashboard with Firebase Firestore Integration

// DOM elements
let navLinks, contentSections, logoutBtn, darkModeToggle;
let saleFormToggleBtn, cancelSaleFormBtn, saleFormCard, saleForm;
let filterBtn, categorySelect, customCategoryGroup, customCategoryInput, categoryHelper;
let customerFormToggleBtn, cancelCustomerFormBtn, customerFormCard, customerForm;
let providerFormToggleBtn, cancelProviderFormBtn, providerFormCard, providerForm;

let salesData = [];
let customersData = [];
let providersData = [];
let chartsInstances = {};

// Initialize dashboard
document.addEventListener('DOMContentLoaded', () => {
  // Get DOM elements
  navLinks = document.querySelectorAll('.nav-link');
  contentSections = document.querySelectorAll('.content-section');
  logoutBtn = document.getElementById('logout-btn');
  darkModeToggle = document.getElementById('dark-mode-toggle');
  saleFormToggleBtn = document.getElementById('toggle-sale-form');
  cancelSaleFormBtn = document.getElementById('cancel-sale-form');
  saleFormCard = document.getElementById('sale-form-card');
  saleForm = document.getElementById('sale-form');
  filterBtn = document.getElementById('filter-btn');
  categorySelect = document.getElementById('form-category');
  customCategoryGroup = document.getElementById('custom-category-group');
  customCategoryInput = document.getElementById('form-category-other');
  categoryHelper = document.getElementById('category-helper');
  customerFormToggleBtn = document.getElementById('toggle-customer-form');
  cancelCustomerFormBtn = document.getElementById('cancel-customer-form');
  customerFormCard = document.getElementById('customer-form-card');
  customerForm = document.getElementById('customer-form');
  providerFormToggleBtn = document.getElementById('toggle-provider-form');
  cancelProviderFormBtn = document.getElementById('cancel-provider-form');
  providerFormCard = document.getElementById('provider-form-card');
  providerForm = document.getElementById('provider-form');

  // Navigation
  navLinks.forEach(link => {
    link.addEventListener('click', (e) => {
      e.preventDefault();
      const section = e.target.closest('.nav-link').dataset.section;
      showSection(section);
    });
  });

  // Logout
  logoutBtn.addEventListener('click', async () => {
    await logoutUser();
  });

  // Dark mode
  darkModeToggle.addEventListener('click', () => {
    document.body.classList.toggle('dark-mode');
    localStorage.setItem('darkMode', document.body.classList.contains('dark-mode'));
  });

  if (localStorage.getItem('darkMode') === 'true') {
    document.body.classList.add('dark-mode');
  }

  // Role Toggle
  const roleToggle = document.getElementById('role-toggle');
  if (roleToggle) {
    roleToggle.addEventListener('change', async (e) => {
      const newRole = e.target.value;
      const success = await switchUserRole(newRole);
      if (success) {
        console.log(`Role switched to: ${newRole}`);
      } else {
        console.error('Failed to switch role');
        // Revert the select to previous value
        roleToggle.value = getCurrentRole();
      }
    });
  }

  if (saleFormToggleBtn) {
    saleFormToggleBtn.addEventListener('click', () => {
      showSection('sales');
      toggleSaleForm();
    });
  }

  if (cancelSaleFormBtn) {
    cancelSaleFormBtn.addEventListener('click', () => {
      toggleSaleForm(false);
    });
  }

  if (saleForm) {
    saleForm.addEventListener('submit', async (e) => {
      e.preventDefault();
      await submitSaleForm();
    });
  }

  if (filterBtn) {
    filterBtn.addEventListener('click', applySalesFilter);
  }

  if (categorySelect) {
    categorySelect.addEventListener('change', handleCategorySelect);
  }

  if (customerFormToggleBtn) {
    customerFormToggleBtn.addEventListener('click', () => {
      showSection('customer');
      toggleCustomerForm(true);
    });
  }

  if (cancelCustomerFormBtn) {
    cancelCustomerFormBtn.addEventListener('click', () => {
      toggleCustomerForm(false);
    });
  }

  if (customerForm) {
    customerForm.addEventListener('submit', async (e) => {
      e.preventDefault();
      await submitCustomerForm();
    });
  }

  if (providerFormToggleBtn) {
    providerFormToggleBtn.addEventListener('click', () => {
      showSection('provider');
      toggleProviderForm(true);
    });
  }

  if (cancelProviderFormBtn) {
    cancelProviderFormBtn.addEventListener('click', () => {
      toggleProviderForm(false);
    });
  }

  if (providerForm) {
    providerForm.addEventListener('submit', async (e) => {
      e.preventDefault();
      await submitProviderForm();
    });
  }

  // Load data
  loadSales();
  loadDashboard();
  loadCustomers();
  loadProviders();
});

function showSection(section) {
  navLinks.forEach(link => link.classList.remove('active'));
  contentSections.forEach(sec => sec.classList.remove('active'));
  
  document.querySelector(`[data-section="${section}"]`).classList.add('active');
  document.getElementById(`${section}-section`).classList.add('active');
  
  const titles = {
    dashboard: 'Dashboard Overview',
    sales: 'Sales Management',
    customer: 'Customer Directory',
    provider: 'Provider Network',
    reports: 'Reports & Analytics'
  };
  document.getElementById('page-title').textContent = titles[section] || section;
}

// Load sales from Firestore
async function loadSales() {
  if (!currentUser) return;

  try {
    const querySnapshot = await db.collection('users').doc(currentUser.uid).collection('sales').get();
    salesData = [];
    
    querySnapshot.forEach(doc => {
      const data = doc.data();
      const dateValue = data.date && data.date.toDate ? data.date.toDate() : data.date;
      salesData.push({
        id: doc.id,
        ...data,
        date: dateValue
      });
    });

    console.log(`✅ Loaded ${salesData.length} sales records`);
    if (salesData.length > 0) {
      console.log('Sample record:', salesData[0]);
    }

    // Auto-add sample data if no data exists
    if (salesData.length === 0) {
      console.log('No sales data found. Adding sample data...');
      await addSampleDataAuto();
    } else {
      displaySalesTable();
      updateDashboard();
    }
  } catch (error) {
    console.error('Error loading sales:', error);
    alert('Failed to load sales data');
  }
}

// Add 10 Sample Entries to Firestore
async function addSampleData() {
  if (!currentUser) {
    alert('Please log in first');
    return;
  }

  const sampleSales = [
    { productName: 'Cloud Server Pro', category: 'Cloud Services', amount: 45000, quantity: 3, region: 'North', customer: 'Tech Corp' },
    { productName: 'Data Backup Plus', category: 'Data Services', amount: 28000, quantity: 5, region: 'South', customer: 'Finance Inc' },
    { productName: 'Security Suite', category: 'Security', amount: 52000, quantity: 2, region: 'East', customer: 'Healthcare Ltd' },
    { productName: 'Analytics Dashboard', category: 'Analytics', amount: 35000, quantity: 4, region: 'West', customer: 'Retail Co' },
    { productName: 'Cloud Server Pro', category: 'Cloud Services', amount: 48000, quantity: 3, region: 'North', customer: 'Startup XYZ' },
    { productName: 'Data Backup Plus', category: 'Data Services', amount: 31000, quantity: 6, region: 'South', customer: 'Education Org' },
    { productName: 'ML Platform', category: 'Analytics', amount: 67000, quantity: 1, region: 'East', customer: 'Research Lab' },
    { productName: 'Security Suite', category: 'Security', amount: 55000, quantity: 2, region: 'West', customer: 'Bank Corp' },
    { productName: 'API Gateway', category: 'Cloud Services', amount: 42000, quantity: 4, region: 'North', customer: 'SaaS Inc' },
    { productName: 'Database Pro', category: 'Data Services', amount: 75000, quantity: 1, region: 'South', customer: 'Enterprise Ltd' }
  ];

  try {
    const userSalesRef = db.collection('users').doc(currentUser.uid).collection('sales');
    
    for (const sale of sampleSales) {
      await userSalesRef.add({
        ...sale,
        date: new Date(),
        createdAt: new Date()
      });
    }

    alert('✅ 10 sample entries added successfully!');
    await loadSales();
  } catch (error) {
    console.error('Error adding sample data:', error);
    alert('Failed to add sample data: ' + error.message);
  }
}

// Auto-add sample data without button (called automatically on first login)
async function addSampleDataAuto() {
  if (!currentUser) return;

  const sampleSales = [
    { productName: 'Cloud Server Pro', category: 'Cloud Services', amount: 45000, quantity: 3, region: 'North', customer: 'Tech Corp' },
    { productName: 'Data Backup Plus', category: 'Data Services', amount: 28000, quantity: 5, region: 'South', customer: 'Finance Inc' },
    { productName: 'Security Suite', category: 'Security', amount: 52000, quantity: 2, region: 'East', customer: 'Healthcare Ltd' },
    { productName: 'Analytics Dashboard', category: 'Analytics', amount: 35000, quantity: 4, region: 'West', customer: 'Retail Co' },
    { productName: 'Cloud Server Pro', category: 'Cloud Services', amount: 48000, quantity: 3, region: 'North', customer: 'Startup XYZ' },
    { productName: 'Data Backup Plus', category: 'Data Services', amount: 31000, quantity: 6, region: 'South', customer: 'Education Org' },
    { productName: 'ML Platform', category: 'Analytics', amount: 67000, quantity: 1, region: 'East', customer: 'Research Lab' },
    { productName: 'Security Suite', category: 'Security', amount: 55000, quantity: 2, region: 'West', customer: 'Bank Corp' },
    { productName: 'API Gateway', category: 'Cloud Services', amount: 42000, quantity: 4, region: 'North', customer: 'SaaS Inc' },
    { productName: 'Database Pro', category: 'Data Services', amount: 75000, quantity: 1, region: 'South', customer: 'Enterprise Ltd' }
  ];

  try {
    const userSalesRef = db.collection('users').doc(currentUser.uid).collection('sales');
    
    for (const sale of sampleSales) {
      await userSalesRef.add({
        ...sale,
        date: new Date(),
        createdAt: new Date()
      });
    }

    console.log('✅ Sample data added automatically');
    await loadSales();
  } catch (error) {
    console.error('Error adding sample data:', error);
  }
}

// Display sales table
function displaySalesTable() {
  const tbody = document.querySelector('#sales-table tbody');
  tbody.innerHTML = '';

  console.log('📊 Displaying sales table with', salesData.length, 'records');
  
  salesData.forEach((sale, index) => {
    const row = document.createElement('tr');
    const date = formatSaleDate(sale.date);
    const displayId = sale.id ? sale.id.substring(0, 8) : `ID-${index + 1}`;
    
    console.log(`Row ${index}:`, { id: sale.id, displayId, product: sale.productName });
    
    row.innerHTML = `
      <td><strong>${displayId}</strong></td>
      <td>${sale.productName || ''}</td>
      <td>${sale.category || ''}</td>
      <td>₹${parseFloat(sale.amount || 0).toLocaleString('en-IN')}</td>
      <td>${sale.quantity || 0}</td>
      <td>${sale.region || ''}</td>
      <td>${date}</td>
      <td>${sale.customer || ''}</td>
      <td>
        <button class="btn-secondary delete-btn" data-id="${sale.id}">🗑️ Delete</button>
      </td>
    `;
    tbody.appendChild(row);
  });

  // Event delegation for delete
  document.querySelectorAll('#sales-table .delete-btn').forEach(btn => {
    btn.addEventListener('click', async (e) => {
      const id = e.target.dataset.id;
      if (confirm('Are you sure you want to delete this sale?')) {
        await deleteSale(id);
      }
    });
  });
}

// Update dashboard metrics
function updateDashboard() {
  let totalSales = 0;
  let totalOrders = salesData.length;
  const productMap = {};
  const categoryMap = {};
  const regionMap = {};
  const regionCount = {};
  const customerMap = {};

  salesData.forEach(sale => {
    const amount = parseFloat(sale.amount || 0);
    totalSales += amount;

    // Products
    if (!productMap[sale.productName]) {
      productMap[sale.productName] = 0;
    }
    productMap[sale.productName] += amount;

    // Categories
    const category = sale.category || 'Other';
    if (!categoryMap[category]) {
      categoryMap[category] = 0;
    }
    categoryMap[category] += amount;

    // Regions
    const region = sale.region || 'Unknown';
    if (!regionMap[region]) {
      regionMap[region] = 0;
      regionCount[region] = 0;
    }
    regionMap[region] += amount;
    regionCount[region] += 1;

    // Customers
    if (!customerMap[sale.customer]) {
      customerMap[sale.customer] = 0;
    }
    customerMap[sale.customer] += 1;
  });

  // Calculate trends (mock data for demo - in real app, compare with previous period)
  const salesTrend = Math.floor(Math.random() * 20) + 5;
  const ordersTrend = Math.floor(Math.random() * 15) + 3;
  const avgTrend = Math.floor(Math.random() * 10) + 2;
  const growthRate = Math.floor(Math.random() * 25) + 10;

  // Update KPI cards with animations
  animateValue('total-sales', 0, totalSales, 1000, '₹');
  animateValue('total-orders', 0, totalOrders, 1000, '');
  animateValue('avg-order-value', 0, totalOrders > 0 ? totalSales / totalOrders : 0, 1000, '₹');
  animateValue('growth', 0, growthRate, 1000, '%');

  // Update trend indicators
  updateTrend('sales-trend', salesTrend, true);
  updateTrend('orders-trend', ordersTrend, true);
  updateTrend('avg-trend', avgTrend, true);
  document.getElementById('growth-trend').textContent = 'vs last month';

  // Create/update charts
  createRevenueChart();
  createProductsChart(productMap);
  createCategoryChart(categoryMap);
  createRegionChart(regionMap);
  createCustomerChart(customerMap);
  renderRegionSummary(regionMap, regionCount, totalSales);
  renderRecentTransactions();
  renderReportSummary(salesData);
}

async function submitSaleForm() {
  if (!currentUser) {
    alert('Please log in to add sales.');
    return;
  }

  const productName = document.getElementById('form-product-name').value.trim();
  const category = getSaleCategory();
  const amount = parseFloat(document.getElementById('form-amount').value);
  const quantity = parseInt(document.getElementById('form-quantity').value, 10);
  const region = document.getElementById('form-region').value.trim();
  const customer = document.getElementById('form-customer').value.trim() || 'Unknown';

  if (!productName || !category || isNaN(amount) || isNaN(quantity) || !region) {
    alert('Please fill all required fields correctly.');
    return;
  }

  try {
    await db.collection('users').doc(currentUser.uid).collection('sales').add({
      productName,
      category,
      amount,
      quantity,
      region,
      customer,
      date: new Date(),
      createdAt: new Date()
    });

    saleForm.reset();
    toggleSaleForm(false);
    if (customCategoryGroup) {
      customCategoryGroup.classList.add('hidden');
    }
    await loadSales();
  } catch (error) {
    console.error('Error adding sale:', error);
    alert('Could not add sale. Please try again.');
  }
}

function getSaleCategory() {
  if (!categorySelect) {
    return document.getElementById('form-category')?.value.trim() || '';
  }

  if (categorySelect.value === 'Other') {
    return customCategoryInput?.value.trim() || '';
  }

  return categorySelect.value.trim();
}

function handleCategorySelect() {
  if (!categorySelect || !customCategoryGroup || !categoryHelper) return;

  const showCustom = categorySelect.value === 'Other';
  customCategoryGroup.classList.toggle('hidden', !showCustom);
  categoryHelper.textContent = showCustom ? 'Please enter a custom category name.' : '';
}

function toggleSaleForm(forceState) {
  if (!saleFormCard) return;
  const isHidden = saleFormCard.classList.contains('hidden');
  const shouldShow = typeof forceState === 'boolean' ? forceState : isHidden;
  saleFormCard.classList.toggle('hidden', !shouldShow);
}

function renderRecentTransactions() {
  const container = document.getElementById('recent-transactions');
  if (!container) return;

  const sorted = [...salesData].sort((a, b) => new Date(b.date) - new Date(a.date));
  const recent = sorted.slice(0, 5);

  if (recent.length === 0) {
    container.innerHTML = '<div class="no-region-data">No transactions yet. Add a new sale to begin.</div>';
    return;
  }

  container.innerHTML = recent.map(sale => {
    const date = formatSaleDate(sale.date);
    return `
      <div class="transaction-row">
        <div class="transaction-main">
          <strong>${sale.productName || 'Unnamed'}</strong>
          <span>${sale.category || 'Uncategorized'}</span>
        </div>
        <div class="transaction-meta">
          <span>${sale.region || 'Region'}</span>
          <span>₹${parseFloat(sale.amount || 0).toLocaleString('en-IN')}</span>
          <span>${date}</span>
        </div>
      </div>
    `;
  }).join('');
}

// Render region summary cards
function formatSaleDate(value) {
  if (!value) return 'N/A';
  const dateValue = value && value.toDate ? value.toDate() : value;
  const date = new Date(dateValue);
  return isNaN(date.getTime()) ? 'N/A' : date.toLocaleDateString();
}

function renderRegionSummary(regionMap, regionCount, totalSales) {
  const container = document.getElementById('region-summary-grid');
  if (!container) return;

  container.innerHTML = '';
  const regions = Object.keys(regionMap);

  if (regions.length === 0) {
    container.innerHTML = '<div class="no-region-data">No regional sales data available yet.</div>';
    return;
  }

  regions.sort((a, b) => regionMap[b] - regionMap[a]);

  regions.forEach(region => {
    const amount = regionMap[region];
    const orders = regionCount[region] || 0;
    const share = totalSales > 0 ? ((amount / totalSales) * 100).toFixed(1) : '0.0';

    const card = document.createElement('div');
    card.className = 'region-card';
    card.innerHTML = `
      <div class="region-card-header">
        <h4>${region}</h4>
        <span>${share}%</span>
      </div>
      <p class="region-card-meta">${orders} sale${orders === 1 ? '' : 's'}</p>
      <p class="region-card-value">$${amount.toFixed(2)}</p>
    `;
    container.appendChild(card);
  });
}

function applySalesFilter() {
  const startInput = document.getElementById('start-date');
  const endInput = document.getElementById('end-date');
  if (!startInput || !endInput) return;

  const startValue = startInput.value;
  const endValue = endInput.value;
  let filtered = [...salesData];

  if (startValue) {
    const startDate = new Date(startValue);
    filtered = filtered.filter(sale => new Date(sale.date) >= startDate);
  }

  if (endValue) {
    const endDate = new Date(endValue);
    endDate.setHours(23, 59, 59, 999);
    filtered = filtered.filter(sale => new Date(sale.date) <= endDate);
  }

  displayFilteredSales(filtered);
}

function displayFilteredSales(filteredSales) {
  const tbody = document.querySelector('#sales-table tbody');
  if (!tbody) return;
  tbody.innerHTML = '';

  if (filteredSales.length === 0) {
    tbody.innerHTML = '<tr><td colspan="9" class="empty-row">No sales match this date range.</td></tr>';
    return;
  }

  filteredSales.forEach(sale => {
    const row = document.createElement('tr');
    const date = formatSaleDate(sale.date);
    row.innerHTML = `
      <td>${sale.id ? sale.id.substring(0, 8) : ''}</td>
      <td>${sale.productName || ''}</td>
      <td>${sale.category || ''}</td>
      <td>$${parseFloat(sale.amount || 0).toFixed(2)}</td>
      <td>${sale.quantity || 0}</td>
      <td>${sale.region || ''}</td>
      <td>${date}</td>
      <td>${sale.customer || ''}</td>
      <td>
        <button class="btn-secondary delete-btn" data-id="${sale.id}">🗑️ Delete</button>
      </td>
    `;
    tbody.appendChild(row);
  });

  document.querySelectorAll('#sales-table .delete-btn').forEach(btn => {
    btn.addEventListener('click', async (e) => {
      const id = e.target.dataset.id;
      if (confirm('Are you sure you want to delete this sale?')) {
        await deleteSale(id);
      }
    });
  });
}

function renderReportSummary(filteredSales) {
  const container = document.getElementById('report-data');
  if (!container) return;

  if (!filteredSales || filteredSales.length === 0) {
    container.innerHTML = '<div class="no-region-data">No sales to report. Add sales or change the date range.</div>';
    return;
  }

  const totalRevenue = filteredSales.reduce((sum, sale) => sum + parseFloat(sale.amount || 0), 0);
  const totalOrders = filteredSales.length;
  const avgOrder = totalOrders > 0 ? totalRevenue / totalOrders : 0;
  const regions = [...new Set(filteredSales.map(sale => sale.region || 'Unknown'))].length;

  container.innerHTML = `
    <div class="report-summary-grid">
      <div class="report-summary-card"><h4>Total Revenue</h4><p>$${totalRevenue.toFixed(2)}</p></div>
      <div class="report-summary-card"><h4>Total Orders</h4><p>${totalOrders}</p></div>
      <div class="report-summary-card"><h4>Avg Order Value</h4><p>$${avgOrder.toFixed(2)}</p></div>
      <div class="report-summary-card"><h4>Active Regions</h4><p>${regions}</p></div>
    </div>
  `;
}

// Animate value changes
function animateValue(elementId, start, end, duration, prefix = '', suffix = '') {
  const element = document.getElementById(elementId);
  const startTime = performance.now();
  const isMoney = prefix === '$';

  function update(currentTime) {
    const elapsed = currentTime - startTime;
    const progress = Math.min(elapsed / duration, 1);

    // Easing function for smooth animation
    const easeOutQuart = 1 - Math.pow(1 - progress, 4);
    const current = start + (end - start) * easeOutQuart;

    if (isMoney) {
      element.textContent = `${prefix}${current.toFixed(2)}`;
    } else if (suffix === '%') {
      element.textContent = `${Math.round(current)}${suffix}`;
    } else {
      element.textContent = `${prefix}${Math.round(current)}${suffix}`;
    }

    if (progress < 1) {
      requestAnimationFrame(update);
    }
  }

  requestAnimationFrame(update);
}

// Update trend indicators
function updateTrend(elementId, value, isPositive) {
  const element = document.getElementById(elementId);
  element.textContent = `${isPositive ? '↗' : '↘'} ${value}%`;
  element.className = `kpi-trend ${isPositive ? 'positive' : 'negative'}`;
}

// Revenue trend chart
function createRevenueChart() {
  const ctx = document.getElementById('revenue-chart');
  if (!ctx) return;

  if (chartsInstances['revenue']) {
    chartsInstances['revenue'].destroy();
  }

  // Generate last 7 days data
  const labels = [];
  const data = [];
  for (let i = 6; i >= 0; i--) {
    const date = new Date();
    date.setDate(date.getDate() - i);
    labels.push(date.toLocaleDateString('en-US', { month: 'short', day: 'numeric' }));
    data.push(Math.floor(Math.random() * 5000) + 1000);
  }

  chartsInstances['revenue'] = new Chart(ctx.getContext('2d'), {
    type: 'line',
    data: {
      labels: labels,
      datasets: [{
        label: 'Revenue',
        data: data,
        borderColor: '#60a5fa',
        backgroundColor: 'rgba(96, 165, 250, 0.1)',
        borderWidth: 3,
        tension: 0.4,
        fill: true,
        pointRadius: 6,
        pointBackgroundColor: '#60a5fa',
        pointBorderColor: '#ffffff',
        pointBorderWidth: 2,
        pointHoverRadius: 8,
        pointHoverBackgroundColor: '#60a5fa',
        pointHoverBorderColor: '#ffffff',
        pointHoverBorderWidth: 3
      }]
    },
    options: {
      responsive: true,
      maintainAspectRatio: true,
      plugins: {
        legend: { display: false }
      },
      scales: {
        y: {
          beginAtZero: true,
          grid: {
            color: 'rgba(0, 0, 0, 0.05)'
          },
          ticks: {
            callback: function(value) {
              return '₹' + value.toLocaleString('en-IN');
            },
            color: '#64748b',
            font: {
              weight: '500'
            }
          }
        },
        x: {
          grid: {
            color: 'rgba(0, 0, 0, 0.05)'
          },
          ticks: {
            color: '#64748b',
            font: {
              weight: '500'
            }
          }
        }
      },
      interaction: {
        intersect: false,
        mode: 'index'
      }
    }
  });
}

// Top Products chart
function createProductsChart(productMap) {
  const ctx = document.getElementById('products-chart');
  if (!ctx) return;

  if (chartsInstances['products']) {
    chartsInstances['products'].destroy();
  }

  // Get top 5 products
  const productEntries = Object.entries(productMap).sort((a, b) => b[1] - a[1]).slice(0, 5);
  const products = productEntries.map(entry => entry[0] || 'Unknown');
  const amounts = productEntries.map(entry => entry[1]);
  
  const colors = [
    'rgba(30, 64, 175, 0.85)',
    'rgba(59, 130, 246, 0.85)',
    'rgba(96, 165, 250, 0.85)',
    'rgba(147, 197, 253, 0.85)',
    'rgba(191, 219, 254, 0.85)'
  ];

  chartsInstances['products'] = new Chart(ctx.getContext('2d'), {
    type: 'bar',
    data: {
      labels: products.length > 0 ? products : ['No Products'],
      datasets: [{
        label: 'Top Products by Sales',
        data: amounts.length > 0 ? amounts : [0],
        backgroundColor: products.map((_, index) => colors[index % colors.length]),
        borderRadius: 8,
        borderSkipped: false
      }]
    },
    options: {
      indexAxis: 'y',
      responsive: true,
      maintainAspectRatio: true,
      plugins: {
        legend: { display: false }
      },
      scales: {
        x: {
          beginAtZero: true,
          grid: { color: 'rgba(0, 0, 0, 0.05)' },
          ticks: {
            callback: function(value) {
              return '₹' + value.toLocaleString('en-IN');
            },
            color: '#64748b',
            font: { weight: '500' }
          }
        },
        y: {
          grid: { display: false },
          ticks: {
            color: '#64748b',
            font: { weight: '500' }
          }
        }
      }
    }
  });
}

// Category chart
function createCategoryChart(categoryMap) {
  const ctx = document.getElementById('category-chart');
  if (!ctx) return;

  if (chartsInstances['category']) {
    chartsInstances['category'].destroy();
  }

  const categories = Object.keys(categoryMap);
  const amounts = categories.map(c => categoryMap[c]);
  const colors = [
    'rgba(96, 165, 250, 0.85)',
    'rgba(168, 85, 247, 0.85)',
    'rgba(16, 185, 129, 0.85)',
    'rgba(239, 68, 68, 0.85)',
    'rgba(234, 179, 8, 0.85)'
  ];

  chartsInstances['category'] = new Chart(ctx.getContext('2d'), {
    type: 'bar',
    data: {
      labels: categories.length > 0 ? categories : ['No Data'],
      datasets: [{
        label: 'Sales by Category',
        data: amounts.length > 0 ? amounts : [0],
        backgroundColor: categories.map((_, index) => colors[index % colors.length]),
        borderRadius: 10,
        borderSkipped: false
      }]
    },
    options: {
      responsive: true,
      maintainAspectRatio: true,
      plugins: {
        legend: { display: false }
      },
      scales: {
        y: {
          beginAtZero: true,
          grid: { color: 'rgba(0, 0, 0, 0.05)' },
          ticks: {
            callback: function(value) {
              return '₹' + value.toLocaleString('en-IN');
            },
            color: '#64748b',
            font: { weight: '500' }
          }
        },
        x: {
          grid: { color: 'rgba(0, 0, 0, 0.05)' },
          ticks: {
            color: '#64748b',
            font: { weight: '500' }
          }
        }
      }
    }
  });
}

// Region sales chart
function createRegionChart(regionMap) {
  const ctx = document.getElementById('region-chart');
  if (!ctx) return;

  if (chartsInstances['region']) {
    chartsInstances['region'].destroy();
  }

  const regions = Object.keys(regionMap);
  const amounts = regions.map(r => regionMap[r]);
  const colors = [
    'rgba(96, 165, 250, 0.8)',
    'rgba(244, 114, 182, 0.8)',
    'rgba(34, 197, 94, 0.8)',
    'rgba(251, 191, 36, 0.8)',
    'rgba(168, 85, 247, 0.8)',
    'rgba(20, 184, 166, 0.8)'
  ];

  chartsInstances['region'] = new Chart(ctx.getContext('2d'), {
    type: 'doughnut',
    data: {
      labels: regions.length > 0 ? regions : ['No Data'],
      datasets: [{
        data: amounts.length > 0 ? amounts : [0],
        backgroundColor: colors.slice(0, regions.length || 1),
        borderColor: colors.slice(0, regions.length || 1).map(color => color.replace('0.8', '1')),
        borderWidth: 2,
        hoverBorderWidth: 4
      }]
    },
    options: {
      responsive: true,
      maintainAspectRatio: true,
      plugins: {
        legend: {
          position: 'bottom',
          labels: {
            padding: 20,
            usePointStyle: true,
            font: {
              weight: '500'
            }
          }
        }
      },
      cutout: '60%'
    }
  });
}

// Customer purchases chart
function createCustomerChart(customerMap) {
  const ctx = document.getElementById('customer-chart');
  if (!ctx) return;

  if (chartsInstances['customer']) {
    chartsInstances['customer'].destroy();
  }

  const customers = Object.keys(customerMap).slice(0, 5);
  const purchases = customers.map(c => customerMap[c]);

  chartsInstances['customer'] = new Chart(ctx.getContext('2d'), {
    type: 'bar',
    data: {
      labels: customers.length > 0 ? customers : ['No Data'],
      datasets: [{
        label: 'Purchases',
        data: purchases.length > 0 ? purchases : [0],
        backgroundColor: 'rgba(34, 197, 94, 0.8)',
        borderColor: '#22c55e',
        borderWidth: 2,
        borderRadius: 8,
        borderSkipped: false,
        hoverBackgroundColor: '#22c55e'
      }]
    },
    options: {
      responsive: true,
      maintainAspectRatio: true,
      plugins: {
        legend: { display: false }
      },
      scales: {
        y: {
          beginAtZero: true,
          grid: {
            color: 'rgba(0, 0, 0, 0.05)'
          },
          ticks: {
            color: '#64748b',
            font: {
              weight: '500'
            }
          }
        },
        x: {
          grid: {
            color: 'rgba(0, 0, 0, 0.05)'
          },
          ticks: {
            color: '#64748b',
            font: {
              weight: '500'
            }
          }
        }
      }
    }
  });
}

function toggleCustomerForm(forceState) {
  if (!customerFormCard) return;
  const isHidden = customerFormCard.classList.contains('hidden');
  const shouldShow = typeof forceState === 'boolean' ? forceState : isHidden;
  customerFormCard.classList.toggle('hidden', !shouldShow);
}

function toggleProviderForm(forceState) {
  if (!providerFormCard) return;
  const isHidden = providerFormCard.classList.contains('hidden');
  const shouldShow = typeof forceState === 'boolean' ? forceState : isHidden;
  providerFormCard.classList.toggle('hidden', !shouldShow);
}

async function submitCustomerForm() {
  if (!currentUser) {
    alert('Please log in first');
    return;
  }
  
  const name = document.getElementById('customer-name').value.trim();
  const email = document.getElementById('customer-email').value.trim();
  const company = document.getElementById('customer-company').value.trim();
  const phone = document.getElementById('customer-phone').value.trim();

  if (!name || !email || !company) {
    alert('Please fill in all required fields (Name, Email, Company)');
    return;
  }

  try {
    console.log('Saving customer:', { name, email, company, phone });
    const docRef = await db.collection('users').doc(currentUser.uid).collection('customers').add({
      name,
      email,
      company,
      phone,
      createdAt: new Date(),
      userId: currentUser.uid
    });
    console.log('✅ Customer saved successfully with ID:', docRef.id);
    alert('✅ Customer saved successfully!');
    customerForm.reset();
    toggleCustomerForm(false);
    await loadCustomers();
  } catch (error) {
    console.error('❌ Error saving customer:', error);
    console.error('Error code:', error.code);
    console.error('Error message:', error.message);
    alert('Could not save customer. Please make sure you are logged in and try again.\nError: ' + error.message);
  }
}

async function submitProviderForm() {
  if (!currentUser) {
    alert('Please log in first');
    return;
  }
  
  const name = document.getElementById('provider-name').value.trim();
  const service = document.getElementById('provider-service').value.trim();
  const company = document.getElementById('provider-company').value.trim();
  const contact = document.getElementById('provider-contact').value.trim();

  if (!name || !service || !company) {
    alert('Please fill in all required fields (Name, Service, Company)');
    return;
  }

  try {
    console.log('Saving provider:', { name, service, company, contact });
    const docRef = await db.collection('users').doc(currentUser.uid).collection('providers').add({
      name,
      service,
      company,
      contact,
      createdAt: new Date(),
      userId: currentUser.uid
    });
    console.log('✅ Provider saved successfully with ID:', docRef.id);
    alert('✅ Provider saved successfully!');
    providerForm.reset();
    toggleProviderForm(false);
    await loadProviders();
  } catch (error) {
    console.error('❌ Error saving provider:', error);
    console.error('Error code:', error.code);
    console.error('Error message:', error.message);
    alert('Could not save provider. Please make sure you are logged in and try again.\nError: ' + error.message);
  }
}

async function loadCustomers() {
  if (!currentUser) {
    console.warn('⚠️ No user logged in - cannot load customers');
    return;
  }
  try {
    console.log('📥 Loading customers for user:', currentUser.uid);
    const snapshot = await db.collection('users').doc(currentUser.uid).collection('customers').get();
    customersData = [];
    snapshot.forEach(doc => customersData.push({ id: doc.id, ...doc.data() }));
    console.log('✅ Loaded', customersData.length, 'customers:', customersData);
    displayCustomerList();
  } catch (error) {
    console.error('❌ Error loading customers:', error);
  }
}

async function loadProviders() {
  if (!currentUser) {
    console.warn('⚠️ No user logged in - cannot load providers');
    return;
  }
  try {
    console.log('📥 Loading providers for user:', currentUser.uid);
    const snapshot = await db.collection('users').doc(currentUser.uid).collection('providers').get();
    providersData = [];
    snapshot.forEach(doc => providersData.push({ id: doc.id, ...doc.data() }));
    console.log('✅ Loaded', providersData.length, 'providers:', providersData);
    displayProviderList();
  } catch (error) {
    console.error('❌ Error loading providers:', error);
  }
}

function displayCustomerList() {
  const tbody = document.querySelector('#customer-table tbody');
  if (!tbody) return;
  tbody.innerHTML = customersData.map(customer => `
    <tr>
      <td>${customer.id.substring(0, 8)}</td>
      <td>${customer.name}</td>
      <td>${customer.email}</td>
      <td>${customer.company}</td>
      <td>${customer.phone || '-'}</td>
      <td><button class="btn-secondary delete-btn" data-id="${customer.id}" data-type="customer">🗑️ Delete</button></td>
    </tr>
  `).join('');

  document.querySelectorAll('#customer-table .delete-btn').forEach(btn => {
    btn.addEventListener('click', async (e) => {
      const id = e.target.dataset.id;
      if (confirm('Delete this customer?')) {
        await deleteCustomer(id);
      }
    });
  });
}

function displayProviderList() {
  const tbody = document.querySelector('#provider-table tbody');
  if (!tbody) return;
  tbody.innerHTML = providersData.map(provider => `
    <tr>
      <td>${provider.id.substring(0, 8)}</td>
      <td>${provider.name}</td>
      <td>${provider.service}</td>
      <td>${provider.company}</td>
      <td>${provider.contact || '-'}</td>
      <td><button class="btn-secondary delete-btn" data-id="${provider.id}" data-type="provider">🗑️ Delete</button></td>
    </tr>
  `).join('');

  document.querySelectorAll('#provider-table .delete-btn').forEach(btn => {
    btn.addEventListener('click', async (e) => {
      const id = e.target.dataset.id;
      if (confirm('Delete this provider?')) {
        await deleteProvider(id);
      }
    });
  });
}

async function deleteCustomer(customerId) {
  if (!currentUser) return;
  try {
    console.log('🗑️ Deleting customer:', customerId);
    await db.collection('users').doc(currentUser.uid).collection('customers').doc(customerId).delete();
    console.log('✅ Customer deleted successfully');
    await loadCustomers();
  } catch (error) {
    console.error('❌ Error deleting customer:', error);
    alert('Could not delete customer. Error: ' + error.message);
  }
}

async function deleteProvider(providerId) {
  if (!currentUser) return;
  try {
    console.log('🗑️ Deleting provider:', providerId);
    await db.collection('users').doc(currentUser.uid).collection('providers').doc(providerId).delete();
    console.log('✅ Provider deleted successfully');
    await loadProviders();
  } catch (error) {
    console.error('❌ Error deleting provider:', error);
    alert('Could not delete provider. Error: ' + error.message);
  }
}

// Add sale
async function openAddSaleModal() {
  const productName = prompt('Product Name:');
  if (!productName) return;

  const category = prompt('Category:');
  if (!category) return;

  const amount = prompt('Amount ($):');
  if (!amount) return;

  const quantity = prompt('Quantity:');
  if (!quantity) return;

  const region = prompt('Region:');
  if (!region) return;

  const customer = prompt('Customer Name:');

  if (!currentUser) return;

  try {
    await db.collection('users').doc(currentUser.uid).collection('sales').add({
      productName: productName,
      category: category,
      amount: parseFloat(amount),
      quantity: parseInt(quantity),
      region: region,
      customer: customer || 'Unknown',
      date: new Date(),
      createdAt: new Date()
    });

    loadSales();
  } catch (error) {
    console.error('Error adding sale:', error);
    alert('Failed to add sale');
  }
}

// Delete sale
async function deleteSale(saleId) {
  if (!currentUser) return;

  try {
    await db.collection('users').doc(currentUser.uid).collection('sales').doc(saleId).delete();
    loadSales();
  } catch (error) {
    console.error('Error deleting sale:', error);
    alert('Failed to delete sale');
  }
}

// Export CSV
document.addEventListener('DOMContentLoaded', () => {
  const exportCsvBtn = document.getElementById('export-csv');
  if (exportCsvBtn) {
    exportCsvBtn.addEventListener('click', () => {
      if (salesData.length === 0) {
        alert('No data to export');
        return;
      }

      let csv = 'Product,Category,Amount,Quantity,Region,Customer,Date\n';
      salesData.forEach(sale => {
        const date = sale.date ? new Date(sale.date).toLocaleDateString() : '';
        csv += `"${sale.productName}","${sale.category}",${sale.amount},${sale.quantity},"${sale.region}","${sale.customer}","${date}"\n`;
      });

      const blob = new Blob([csv], { type: 'text/csv' });
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = 'sales_export.csv';
      a.click();
      window.URL.revokeObjectURL(url);
    });
  }
});

// Load dashboard on startup
function loadDashboard() {
  // This is called to ensure charts are initialized
  updateDashboard();
}