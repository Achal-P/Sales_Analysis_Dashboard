/* Chart.js Custom Configuration */

// Chart color palette matching Figma design
const chartColors = {
  blue: '#2563eb',
  green: '#10b981',
  orange: '#f59e0b',
  red: '#ef4444',
  yellow: '#fbbf24',
  purple: '#a855f7',
};

// Revenue Trend Chart
function createRevenueChart() {
  const ctx = document.getElementById('revenue-chart');
  if (!ctx) return;
  
  if (window.revenueChart instanceof Chart) {
    window.revenueChart.destroy();
  }

  window.revenueChart = new Chart(ctx, {
    type: 'line',
    data: {
      labels: ['Apr 01', 'Apr 02', 'Apr 03', 'Apr 04', 'Apr 05', 'Apr 06', 'Apr 07', 'Apr 08'],
      datasets: [{
        label: 'Revenue',
        data: [30000, 25000, 45000, 50000, 40000, 55000, 60000, 35000],
        borderColor: chartColors.blue,
        backgroundColor: 'rgba(37, 99, 235, 0.05)',
        borderWidth: 3,
        fill: true,
        tension: 0.4,
        pointBackgroundColor: chartColors.blue,
        pointRadius: 5,
        pointHoverRadius: 7,
        pointBorderWidth: 0,
      }],
    },
    options: {
      responsive: true,
      maintainAspectRatio: true,
      plugins: {
        legend: { display: false },
        tooltip: {
          backgroundColor: 'rgba(0, 0, 0, 0.8)',
          padding: 12,
          titleFont: { size: 14, weight: 'bold' },
          bodyFont: { size: 13 },
          borderColor: chartColors.blue,
          borderWidth: 1,
        },
      },
      scales: {
        y: {
          beginAtZero: true,
          grid: {
            color: 'rgba(0, 0, 0, 0.05)',
            drawBorder: false,
          },
          ticks: {
            color: '#94a3b8',
            font: { size: 12 },
            callback: function(value) {
              return '₹' + (value / 1000).toFixed(0) + 'K';
            },
          },
        },
        x: {
          grid: { display: false },
          ticks: {
            color: '#94a3b8',
            font: { size: 12 },
          },
        },
      },
    },
  });
}

// Sales by Category Chart
function createCategoryChart(categoryMap) {
  const ctx = document.getElementById('category-chart');
  if (!ctx) return;

  const labels = Object.keys(categoryMap);
  const data = Object.values(categoryMap);
  const colors = [chartColors.blue, chartColors.green, chartColors.orange, chartColors.red];

  if (window.categoryChart instanceof Chart) {
    window.categoryChart.destroy();
  }

  window.categoryChart = new Chart(ctx, {
    type: 'bar',
    data: {
      labels: labels,
      datasets: [{
        label: 'Sales',
        data: data,
        backgroundColor: colors.slice(0, labels.length),
        borderRadius: 6,
        borderSkipped: false,
      }],
    },
    options: {
      responsive: true,
      maintainAspectRatio: true,
      plugins: {
        legend: { display: false },
        tooltip: {
          backgroundColor: 'rgba(0, 0, 0, 0.8)',
          padding: 12,
          titleFont: { size: 14, weight: 'bold' },
          bodyFont: { size: 13 },
        },
      },
      scales: {
        y: {
          beginAtZero: true,
          grid: {
            color: 'rgba(0, 0, 0, 0.05)',
            drawBorder: false,
          },
          ticks: {
            color: '#94a3b8',
            font: { size: 12 },
            callback: function(value) {
              return '₹' + (value / 1000).toFixed(0) + 'K';
            },
          },
        },
        x: {
          grid: { display: false },
          ticks: {
            color: '#94a3b8',
            font: { size: 12 },
          },
        },
      },
    },
  });
}

// Sales by Region Chart
function createRegionChart(regionMap) {
  const ctx = document.getElementById('region-chart');
  if (!ctx) return;

  const labels = Object.keys(regionMap);
  const data = Object.values(regionMap);
  const colors = [chartColors.blue, chartColors.green, chartColors.orange, chartColors.red];

  if (window.regionChart instanceof Chart) {
    window.regionChart.destroy();
  }

  window.regionChart = new Chart(ctx, {
    type: 'doughnut',
    data: {
      labels: labels,
      datasets: [{
        data: data,
        backgroundColor: colors.slice(0, labels.length),
        borderColor: '#ffffff',
        borderWidth: 2,
      }],
    },
    options: {
      responsive: true,
      maintainAspectRatio: true,
      plugins: {
        legend: {
          position: 'bottom',
          labels: {
            color: '#1e293b',
            font: { size: 12, weight: '500' },
            padding: 16,
            usePointStyle: true,
            pointStyle: 'circle',
          },
        },
        tooltip: {
          backgroundColor: 'rgba(0, 0, 0, 0.8)',
          padding: 12,
          titleFont: { size: 14, weight: 'bold' },
          bodyFont: { size: 13 },
          callbacks: {
            label: function(context) {
              const total = context.dataset.data.reduce((a, b) => a + b, 0);
              const percentage = ((context.parsed / total) * 100).toFixed(1);
              return ` ₹${(context.parsed / 1000).toFixed(0)}K (${percentage}%)`;
            },
          },
        },
      },
    },
  });
}

// Customer Chart
function createCustomerChart(customerMap) {
  const ctx = document.getElementById('customer-chart');
  if (!ctx) return;

  const topCustomers = Object.entries(customerMap)
    .sort((a, b) => b[1] - a[1])
    .slice(0, 5);
  
  const labels = topCustomers.map(([name]) => name);
  const data = topCustomers.map(([, count]) => count);

  if (window.customerChart instanceof Chart) {
    window.customerChart.destroy();
  }

  window.customerChart = new Chart(ctx, {
    type: 'bar',
    data: {
      labels: labels,
      datasets: [{
        label: 'Orders',
        data: data,
        backgroundColor: chartColors.purple,
        borderRadius: 6,
      }],
    },
    options: {
      indexAxis: 'y',
      responsive: true,
      maintainAspectRatio: true,
      plugins: {
        legend: { display: false },
        tooltip: {
          backgroundColor: 'rgba(0, 0, 0, 0.8)',
          padding: 12,
          titleFont: { size: 14, weight: 'bold' },
          bodyFont: { size: 13 },
        },
      },
      scales: {
        x: {
          beginAtZero: true,
          grid: {
            color: 'rgba(0, 0, 0, 0.05)',
            drawBorder: false,
          },
          ticks: {
            color: '#94a3b8',
            font: { size: 12 },
          },
        },
        y: {
          grid: { display: false },
          ticks: {
            color: '#94a3b8',
            font: { size: 12 },
          },
        },
      },
    },
  });
}

// Products Chart
function createProductsChart(productMap) {
  const ctx = document.getElementById('products-chart');
  if (!ctx) return;

  const topProducts = Object.entries(productMap)
    .sort((a, b) => b[1] - a[1])
    .slice(0, 5);
  
  const labels = topProducts.map(([name]) => name);
  const data = topProducts.map(([, amount]) => amount);
  const colors = [chartColors.blue, chartColors.green, chartColors.orange, chartColors.red, chartColors.purple];

  if (window.productsChart instanceof Chart) {
    window.productsChart.destroy();
  }

  window.productsChart = new Chart(ctx, {
    type: 'doughnut',
    data: {
      labels: labels,
      datasets: [{
        data: data,
        backgroundColor: colors.slice(0, labels.length),
        borderColor: '#ffffff',
        borderWidth: 2,
      }],
    },
    options: {
      responsive: true,
      maintainAspectRatio: true,
      plugins: {
        legend: {
          position: 'right',
          labels: {
            color: '#1e293b',
            font: { size: 11, weight: '500' },
            padding: 12,
            usePointStyle: true,
            pointStyle: 'circle',
          },
        },
        tooltip: {
          backgroundColor: 'rgba(0, 0, 0, 0.8)',
          padding: 12,
          titleFont: { size: 14, weight: 'bold' },
          bodyFont: { size: 13 },
        },
      },
    },
  });
}

// Export functions
window.createRevenueChart = createRevenueChart;
window.createCategoryChart = createCategoryChart;
window.createRegionChart = createRegionChart;
window.createCustomerChart = createCustomerChart;
window.createProductsChart = createProductsChart;
