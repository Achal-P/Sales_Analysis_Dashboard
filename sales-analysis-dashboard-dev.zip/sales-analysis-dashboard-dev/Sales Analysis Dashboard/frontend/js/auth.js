// Firebase Configuration
const firebaseConfig = {
  apiKey: "AIzaSyAJGExoDwXtQyWAumazNtBDP6mc5rmfACk",
  authDomain: "sales-analysis-dashboard-f7dab.firebaseapp.com",
  projectId: "sales-analysis-dashboard-f7dab",
  storageBucket: "sales-analysis-dashboard-f7dab.firebasestorage.app",
  messagingSenderId: "660175278485",
  appId: "1:660175278485:web:215a38e369a5ad4dc1269c",
  measurementId: "G-B2MRE44W69"
};

// Initialize Firebase
firebase.initializeApp(firebaseConfig);
const auth = firebase.auth();
const db = firebase.firestore();

console.log('Firebase initialized', !!firebase, !!auth, !!db);

// Auth State Management
let currentUser = null;
let userRole = 'customer'; // Default role

auth.onAuthStateChanged(async (user) => {
  currentUser = user;
  if (user) {
    // Load user role from Firestore
    await loadUserRole();
  } else {
    userRole = 'customer';
  }
  updateUI();
});

// Load user role from Firestore
async function loadUserRole() {
  try {
    const doc = await db.collection('users').doc(currentUser.uid).get();
    if (doc.exists) {
      userRole = doc.data().role || 'customer';
    } else {
      userRole = 'customer';
    }
    applyRoleUI();
  } catch (error) {
    console.error('Error loading user role:', error);
    userRole = 'customer';
  }
}

// Apply UI changes based on role
function applyRoleUI() {
  const body = document.body;
  body.classList.remove('customer-role', 'provider-role');
  body.classList.add(`${userRole}-role`);
  
  // Update role display
  const roleElement = document.getElementById('user-role');
  if (roleElement) {
    roleElement.textContent = userRole === 'customer' ? '🛒 Customer' : '🏢 Provider';
  }
  
  // Update role selector
  const roleToggle = document.getElementById('role-toggle');
  if (roleToggle) {
    roleToggle.value = userRole;
  }
}

// Update UI based on auth state
function updateUI() {
  const loginContainer = document.getElementById('login-container');
  const dashboardContainer = document.getElementById('dashboard-container');
  
  if (currentUser) {
    if (loginContainer) loginContainer.style.display = 'none';
    if (dashboardContainer) dashboardContainer.style.display = 'flex';
    if (document.getElementById('user-email')) {
      document.getElementById('user-email').textContent = currentUser.email;
    }
    applyRoleUI();
    loadSales();
  } else {
    if (loginContainer) loginContainer.style.display = 'flex';
    if (dashboardContainer) dashboardContainer.style.display = 'none';
  }
}

// Login
async function loginUser(email, password) {
  try {
    const result = await auth.signInWithEmailAndPassword(email, password);
    return { success: true, user: result.user };
  } catch (error) {
    return { success: false, error: error.message };
  }
}

// Register with Role
async function registerUser(email, password, displayName, role = 'customer') {
  try {
    const result = await auth.createUserWithEmailAndPassword(email, password);
    await result.user.updateProfile({ displayName });
    
    // Store user data in Firestore with role
    await db.collection('users').doc(result.user.uid).set({
      email: email,
      displayName: displayName,
      createdAt: new Date(),
      role: role || 'customer'
    });
    
    userRole = role || 'customer';
    return { success: true, user: result.user };
  } catch (error) {
    return { success: false, error: error.message };
  }
}

// Switch user role
async function switchUserRole(newRole) {
  if (!currentUser) {
    console.error('User not authenticated');
    return false;
  }
  
  try {
    await db.collection('users').doc(currentUser.uid).update({
      role: newRole
    });
    userRole = newRole;
    applyRoleUI();
    return true;
  } catch (error) {
    console.error('Error switching role:', error);
    return false;
  }
}

// Get current user role
function getCurrentRole() {
  return userRole;
}

// Logout
async function logoutUser() {
  try {
    await auth.signOut();
    userRole = 'customer';
    return { success: true };
  } catch (error) {
    return { success: false, error: error.message };
  }
}

// Get current user
function getCurrentUser() {
  return currentUser;
}

// Check if user is authenticated
function isAuthenticated() {
  return currentUser !== null;
}
