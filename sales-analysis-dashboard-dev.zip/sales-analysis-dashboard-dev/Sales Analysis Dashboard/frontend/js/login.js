// Firebase Login and Registration Handlers with Role Management

function toggleAuthForm() {
  const loginForm = document.getElementById('login-form-wrapper');
  const signupForm = document.getElementById('signup-form-wrapper');
  
  loginForm.classList.toggle('active');
  signupForm.classList.toggle('active');
  
  // Clear error messages
  document.getElementById('auth-error').textContent = '';
  document.getElementById('auth-success').textContent = '';
}

// Login Form Handler
document.getElementById('login-form').addEventListener('submit', async (e) => {
  e.preventDefault();
  
  const email = document.getElementById('login-email').value;
  const password = document.getElementById('login-password').value;
  const errorDiv = document.getElementById('auth-error');
  
  errorDiv.textContent = 'Signing in...';
  
  const result = await loginUser(email, password);
  
  if (result.success) {
    errorDiv.textContent = '';
    document.getElementById('auth-success').textContent = 'Login successful! Redirecting...';
    // The updateUI() triggered by onAuthStateChanged will handle the redirect
  } else {
    errorDiv.textContent = result.error.includes('configuration-not-found')
      ? 'Firebase auth is not configured for this domain. Run the app from http://localhost:8080 and add localhost/127.0.0.1 to Firebase authorized domains.'
      : result.error;
  }
});

// Signup Form Handler with Role Selection
document.getElementById('signup-form').addEventListener('submit', async (e) => {
  e.preventDefault();
  
  const name = document.getElementById('signup-name').value;
  const email = document.getElementById('signup-email').value;
  const role = document.getElementById('signup-role').value;
  const password = document.getElementById('signup-password').value;
  const confirm = document.getElementById('signup-confirm').value;
  const errorDiv = document.getElementById('auth-error');
  const successDiv = document.getElementById('auth-success');
  
  errorDiv.textContent = '';
  successDiv.textContent = '';
  
  // Validate role is selected
  if (!role) {
    errorDiv.textContent = 'Please select an account type';
    return;
  }
  
  // Validate passwords match
  if (password !== confirm) {
    errorDiv.textContent = 'Passwords do not match';
    return;
  }
  
  if (password.length < 6) {
    errorDiv.textContent = 'Password must be at least 6 characters';
    return;
  }
  
  successDiv.textContent = 'Creating account...';
  
  const result = await registerUser(email, password, name, role);
  
  if (result.success) {
    successDiv.textContent = 'Account created successfully! Redirecting...';
    // The updateUI() triggered by onAuthStateChanged will handle the redirect
  } else {
    errorDiv.textContent = result.error.includes('configuration-not-found')
      ? 'Firebase auth is not configured for this domain. Run the app from http://localhost:8080 and add localhost/127.0.0.1 to Firebase authorized domains.'
      : result.error;
    successDiv.textContent = '';
  }
});

// Auto-hide messages
function clearMessages() {
  setTimeout(() => {
    document.getElementById('auth-error').textContent = '';
    document.getElementById('auth-success').textContent = '';
  }, 5000);
}