from flask import Blueprint, request, jsonify, session
from models import db, User, Sale
from werkzeug.security import generate_password_hash, check_password_hash
from datetime import datetime
from sqlalchemy import func, extract

routes = Blueprint('routes', __name__)

@routes.route('/api/login', methods=['POST'])
def login():
    data = request.get_json()
    user = User.query.filter_by(username=data['username']).first()
    if user and check_password_hash(user.password_hash, data['password']):
        session['user_id'] = user.id
        return jsonify({'message': 'Login successful', 'role': user.role})
    return jsonify({'message': 'Invalid credentials'}), 401

@routes.route('/api/logout', methods=['POST'])
def logout():
    session.pop('user_id', None)
    return jsonify({'message': 'Logged out'})

@routes.route('/api/sales', methods=['GET', 'POST'])
def sales():
    if 'user_id' not in session:
        return jsonify({'message': 'Unauthorized'}), 401
    if request.method == 'GET':
        sales = Sale.query.all()
        return jsonify([{
            'id': s.id,
            'product_name': s.product_name,
            'category': s.category,
            'amount': s.amount,
            'quantity': s.quantity,
            'region': s.region,
            'date': s.date.isoformat(),
            'customer': s.customer
        } for s in sales])
    data = request.get_json()
    new_sale = Sale(
        product_name=data['product_name'],
        category=data['category'],
        amount=data['amount'],
        quantity=data['quantity'],
        region=data['region'],
        date=datetime.fromisoformat(data['date']),
        customer=data.get('customer')
    )
    db.session.add(new_sale)
    db.session.commit()
    return jsonify({'message': 'Sale added', 'id': new_sale.id}), 201

@routes.route('/api/sales/<int:id>', methods=['PUT', 'DELETE'])
def sale(id):
    if 'user_id' not in session:
        return jsonify({'message': 'Unauthorized'}), 401
    sale = Sale.query.get_or_404(id)
    if request.method == 'PUT':
        data = request.get_json()
        sale.product_name = data['product_name']
        sale.category = data['category']
        sale.amount = data['amount']
        sale.quantity = data['quantity']
        sale.region = data['region']
        sale.date = datetime.fromisoformat(data['date'])
        sale.customer = data.get('customer')
        db.session.commit()
        return jsonify({'message': 'Sale updated'})
    db.session.delete(sale)
    db.session.commit()
    return jsonify({'message': 'Sale deleted'})

@routes.route('/api/dashboard-summary')
def dashboard_summary():
    if 'user_id' not in session:
        return jsonify({'message': 'Unauthorized'}), 401
    total_sales = db.session.query(db.func.sum(Sale.amount)).scalar() or 0
    total_orders = Sale.query.count()
    # Revenue trend monthly - last 12 months
    monthly_revenue = db.session.query(
        extract('year', Sale.date).label('year'),
        extract('month', Sale.date).label('month'),
        func.sum(Sale.amount).label('revenue')
    ).group_by('year', 'month').order_by('year', 'month').all()
    revenue_trend = [{'month': f"{int(r.year)}-{int(r.month):02d}", 'revenue': r.revenue} for r in monthly_revenue]
    # Top products
    top_products = db.session.query(
        Sale.product_name,
        func.sum(Sale.amount).label('total')
    ).group_by(Sale.product_name).order_by(func.sum(Sale.amount).desc()).limit(5).all()
    top_products = [{'product': p.product_name, 'total': p.total} for p in top_products]
    # Region-wise
    region_sales = db.session.query(
        Sale.region,
        func.sum(Sale.amount).label('total')
    ).group_by(Sale.region).all()
    region_sales = [{'region': r.region, 'total': r.total} for r in region_sales]
    # Customer-wise
    customer_sales = db.session.query(
        Sale.customer,
        func.sum(Sale.amount).label('total')
    ).filter(Sale.customer.isnot(None)).group_by(Sale.customer).order_by(func.sum(Sale.amount).desc()).limit(5).all()
    customer_sales = [{'customer': c.customer, 'total': c.total} for c in customer_sales]
    return jsonify({
        'total_sales': total_sales,
        'total_orders': total_orders,
        'revenue_trend': revenue_trend,
        'top_products': top_products,
        'region_sales': region_sales,
        'customer_sales': customer_sales
    })