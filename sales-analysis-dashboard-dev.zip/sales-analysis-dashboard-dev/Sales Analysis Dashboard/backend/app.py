from flask import Flask, jsonify
from flask_cors import CORS
from config import Config
from models import db
from routes import routes
import logging
import os
from datetime import datetime

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

app = Flask(__name__)
app.config.from_object(Config)
db.init_app(app)

# Enhanced CORS configuration
CORS(app, resources={
    r"/api/*": {
        "origins": ["*"],
        "methods": ["GET", "POST", "PUT", "DELETE", "OPTIONS"],
        "allow_headers": ["Content-Type", "Authorization"]
    }
})

app.register_blueprint(routes, url_prefix='/api')

# Security headers middleware
@app.after_request
def set_security_headers(response):
    response.headers['X-Content-Type-Options'] = 'nosniff'
    response.headers['X-Frame-Options'] = 'SAMEORIGIN'
    response.headers['X-XSS-Protection'] = '1; mode=block'
    response.headers['Referrer-Policy'] = 'strict-origin-when-cross-origin'
    response.headers['Permissions-Policy'] = 'geolocation=(), microphone=(), camera=()'
    return response

# Error handlers
@app.errorhandler(404)
def not_found(error):
    logger.warning(f"404 Error: {error}")
    return jsonify({'error': 'Resource not found', 'status': 404}), 404

@app.errorhandler(500)
def internal_error(error):
    logger.error(f"500 Error: {error}")
    db.session.rollback()
    return jsonify({'error': 'Internal server error', 'status': 500}), 500

@app.errorhandler(403)
def forbidden(error):
    logger.warning(f"403 Error: {error}")
    return jsonify({'error': 'Forbidden', 'status': 403}), 403

# Health check endpoint
@app.route('/health', methods=['GET'])
def health():
    return jsonify({
        'status': 'healthy',
        'timestamp': datetime.utcnow().isoformat(),
        'version': '2.0'
    }), 200

# API info endpoint
@app.route('/api/info', methods=['GET'])
def api_info():
    return jsonify({
        'name': 'Sales Analysis Dashboard API',
        'version': '2.0',
        'timestamp': datetime.utcnow().isoformat(),
        'endpoints': {
            'auth': '/api/login, /api/logout, /api/register',
            'sales': '/api/sales (GET, POST)', 
            'sales_item': '/api/sales/<id> (GET, PUT, DELETE)',
            'analytics': '/api/sales/analytics/summary'
        }
    }), 200

if __name__ == '__main__':
    with app.app_context():
        try:
            db.create_all()
            logger.info("Database initialized successfully")
            
            # Add a default user if not exists
            from models import User, Sale
            from werkzeug.security import generate_password_hash
            from datetime import date
            
            if not User.query.filter_by(username='admin').first():
                admin = User(username='admin', password_hash=generate_password_hash('password'), role='admin')
                db.session.add(admin)
                db.session.commit()
                logger.info("Admin user created")
            
            # Add sample data if database is empty
            if Sale.query.count() == 0:
                sales = [
                    Sale(product_name='Laptop', category='Electronics', amount=1200.00, quantity=1, region='North', date=date(2023, 1, 15), customer='John Doe'),
                    Sale(product_name='Mouse', category='Electronics', amount=25.00, quantity=2, region='South', date=date(2023, 2, 10), customer='Jane Smith'),
                    Sale(product_name='Keyboard', category='Electronics', amount=75.00, quantity=1, region='East', date=date(2023, 3, 5), customer='Bob Johnson'),
                    Sale(product_name='Monitor', category='Electronics', amount=300.00, quantity=1, region='West', date=date(2023, 4, 20), customer='Alice Brown'),
                    Sale(product_name='Chair', category='Furniture', amount=150.00, quantity=1, region='North', date=date(2023, 5, 12), customer='Charlie Wilson'),
                    Sale(product_name='Desk', category='Furniture', amount=250.00, quantity=1, region='South', date=date(2023, 6, 8), customer='Diana Davis'),
                    Sale(product_name='Laptop', category='Electronics', amount=1100.00, quantity=1, region='East', date=date(2023, 7, 15), customer='Eve Garcia'),
                    Sale(product_name='Mouse', category='Electronics', amount=20.00, quantity=3, region='West', date=date(2023, 8, 22), customer='Frank Miller'),
                    Sale(product_name='Headphones', category='Electronics', amount=100.00, quantity=1, region='North', date=date(2023, 9, 10), customer='Grace Lee'),
                    Sale(product_name='Webcam', category='Electronics', amount=80.00, quantity=1, region='South', date=date(2023, 10, 5), customer='Henry Taylor'),
                ]
                for sale in sales:
                    db.session.add(sale)
                db.session.commit()
                logger.info(f"Sample data ({len(sales)} sales) initialized")
        except Exception as e:
            logger.error(f"Initialization error: {str(e)}")
            raise

    # Run development server
    debug_mode = os.environ.get('FLASK_ENV') != 'production'
    app.run(debug=debug_mode, host='0.0.0.0', port=5000)