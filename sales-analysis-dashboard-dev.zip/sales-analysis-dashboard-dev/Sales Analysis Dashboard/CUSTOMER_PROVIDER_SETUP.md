# 🚀 ESDS Sales Dashboard - Customer & Provider Setup Guide

## ✅ What's Working Now

- ✅ Customer form submission with error logging
- ✅ Provider form submission with error logging  
- ✅ Delete customer button
- ✅ Delete provider button
- ✅ Firebase Firestore storage for all data
- ✅ User-specific data isolation

## ⚡ CRITICAL: Update Firestore Security Rules

The main reason the "Save Customer" and "Save Provider" buttons may not be working is **Firestore Security Rules**.

### Step 1: Open Firebase Console
1. Go to [Firebase Console](https://console.firebase.google.com)
2. Select project: **sales-analysis-dashboard-f7dab**
3. Click **Firestore Database** in the left menu
4. Click the **Rules** tab

### Step 2: Replace Security Rules

Delete all existing rules and paste this:

```javascript
rules_version = '2';
service cloud.firestore {
  match /databases/{database}/documents {
    // User data - users can only access their own
    match /users/{userId} {
      allow read, write: if request.auth.uid == userId;
      
      // Sales collection
      match /sales/{document=**} {
        allow read, write: if request.auth.uid == userId;
      }
      
      // Customers collection
      match /customers/{document=**} {
        allow read, write: if request.auth.uid == userId;
      }
      
      // Providers collection
      match /providers/{document=**} {
        allow read, write: if request.auth.uid == userId;
      }
    }
  }
}
```

### Step 3: Publish Rules
Click the **Publish** button (blue button at top right)

---

## 🧪 Test the Buttons

### 1. Hard Refresh Browser
```
Ctrl + Shift + R  (Windows/Linux)
or
Cmd + Shift + R   (Mac)
```

### 2. Sign In
- Use your Google account or email/password
- Make sure you're in **Customer** role (check the role selector in sidebar)

### 3. Add a Customer
1. Click **+ ADD CUSTOMER** button
2. Fill in the form:
   - **Customer Name:** Sujit Rane
   - **Email:** sujit@example.com
   - **Company:** ESDS
   - **Phone:** 9876543210
3. Click **SAVE CUSTOMER**
4. Should see: ✅ Customer saved successfully!

### 4. Add a Provider (Switch to Provider Role)
1. In sidebar, change role to **Provider** 
2. Navigation will show "My Providers" 
3. Click **+ ADD PROVIDER**
4. Fill details and save
5. Should work the same way

### 5. Check Firebase Console
1. Go to Firebase Console
2. Click **Firestore Database** → **Data** tab
3. Look for:
   - `users` → `[YOUR_USER_ID]` → `customers`
   - `users` → `[YOUR_USER_ID]` → `providers`
4. You should see your saved entries!

---

## 🔍 Troubleshooting

### If you see: "Could not save customer"

**Step 1: Check Browser Console (F12)**
```
Press: F12 on keyboard
Go to: Console tab
Look for error messages starting with ❌
```

**Step 2: Common Error Messages**

| Error | Solution |
|-------|----------|
| `permission-denied` | Update Firestore security rules (see Step 2 above) |
| `not-authenticated` | Sign out and sign in again |
| `invalid-argument` | Check all form fields are filled |
| `network-error` | Check internet connection |

**Step 3: Check Firestore Rules**
1. Go to Firebase Console → Firestore → Rules
2. Look for any **error indicators** (red X)
3. Rules must have `✅` green checkmark

---

## 📊 Data Storage Structure

When you save a customer, it's stored like this:

```
Firestore Database
└── users
    └── [YOUR_USER_ID]
        ├── customers
        │   ├── Document 1
        │   │   ├── name: "Sujit Rane"
        │   │   ├── email: "sujit@example.com"
        │   │   ├── company: "Aress"
        │   │   ├── phone: "9760453340"
        │   │   └── createdAt: [timestamp]
        │   └── Document 2...
        │
        ├── providers
        │   └── [similar structure]
        │
        └── sales
            └── [similar structure]
```

**Key Feature:** Each user's data is completely isolated and secure!

---

## ✅ Complete Checklist

- [ ] Logged in to Firebase Console
- [ ] Updated Firestore Security Rules (copy-pasted the code above)
- [ ] Clicked **Publish** on rules
- [ ] Hard refreshed browser (Ctrl+Shift+R)
- [ ] Signed into ESDS Dashboard
- [ ] Tried adding a customer - worked ✅
- [ ] Checked Firebase Console for saved data ✅
- [ ] Tried deleting a customer - worked ✅

---

## 💡 Pro Tips

1. **Use DevTools Console (F12)** to see detailed logs:
   - 📥 "Loading customers..."
   - ✅ "Loaded 5 customers"
   - 🗑️ "Deleting customer..."

2. **Test with Sample Data:**
   - Name: "Sujit Rane"
   - Email: "sujit@example.com"
   - Company: "Aress"
   - Phone: "9760453340"

3. **Multiple Roles:** You can switch between Customer and Provider roles to manage both

---

## 🆘 Still Having Issues?

1. Open browser DevTools (F12)
2. Go to Console tab
3. Try to add a customer
4. Copy the **full error message** 
5. Share it with support

The error code will start with `❌` and include:
- Error type (permission-denied, network-error, etc.)
- Collection path (/users/...")
- Exact error message

This helps us debug faster! ✅
