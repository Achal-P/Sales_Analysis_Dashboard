@echo off
REM ====================================================================
REM Sales Dashboard - One-Click Deployment Script (Windows)
REM ====================================================================

setlocal enabledelayedexpansion

echo.
echo ========================================
echo  Sales Dashboard - Deployment Tool
echo ========================================
echo.

REM Check if running in correct directory
if not exist "backend" (
    echo ERROR: Please run this script from the project root directory
    pause
    exit /b 1
)

REM Menu
:menu
echo.
echo Select an option:
echo 1. Development Setup (Backend + Frontend)
echo 2. Production Setup (Gunicorn)
echo 3. Install Dependencies
echo 4. Reset Database
echo 5. Health Check
echo 6. Stop All Servers
echo 7. Exit
echo.
set /p choice="Enter your choice (1-7): "

if "%choice%"=="1" goto dev_setup
if "%choice%"=="2" goto prod_setup
if "%choice%"=="3" goto install_deps
if "%choice%"=="4" goto reset_db
if "%choice%"=="5" goto health_check
if "%choice%"=="6" goto stop_servers
if "%choice%"=="7" exit /b 0

echo Invalid choice. Please try again.
goto menu

:install_deps
echo.
echo Installing Python dependencies...
cd backend
pip install -r requirements.txt
cd ..
echo ✓ Dependencies installed successfully
goto menu

:dev_setup
echo.
echo Starting Development Environment...
echo.
echo Stopping any existing processes...
taskkill /F /IM python.exe 2>nul

echo.
echo Starting Flask Backend Server (Port 5000)...
start cmd /k "cd backend && python app.py"

echo Waiting 3 seconds for backend to start...
timeout /t 3

echo.
echo Starting Frontend Server (Port 8080)...
start cmd /k "cd frontend && python -m http.server 8080"

echo.
echo ========================================
echo ✓ Development environment started!
echo.
echo Access your application at:
echo   Frontend: http://localhost:8080/index.html
echo   Backend:  http://localhost:5000
echo   Health:   http://localhost:5000/health
echo.
echo Press any key to return to menu...
pause >nul
goto menu

:prod_setup
echo.
echo Production Setup - Installing Gunicorn...
pip install gunicorn

echo.
echo Starting Production Server (Gunicorn - Port 5000)...
start cmd /k "cd backend && gunicorn -w 4 -b 0.0.0.0:5000 --access-logfile - --error-logfile - app:app"

echo.
echo ✓ Production server started with Gunicorn (4 workers)
echo Frontend should be served by Nginx or another web server
echo.
echo Access backend at: http://localhost:5000
echo Press any key to return to menu...
pause >nul
goto menu

:reset_db
echo.
echo WARNING: This will delete all data and reset the database!
set /p confirm="Are you sure? (yes/no): "

if /i not "%confirm%"=="yes" (
    echo Reset cancelled
    goto menu
)

echo Resetting database...
cd backend
del /q sales.db 2>nul
echo Creating fresh database...
python -c "from app import app, db; app.app_context().push(); db.create_all(); print('Database reset successfully')"
cd ..

echo ✓ Database reset complete
goto menu

:health_check
echo.
echo Checking backend health...
powershell -Command "try { $response = Invoke-WebRequest -Uri 'http://localhost:5000/health' -UseBasicParsing; Write-Host ('✓ Backend is running'); Write-Host $response.Content } catch { Write-Host '✗ Backend is not responding'; Write-Host $_  }"
goto menu

:stop_servers
echo.
echo Stopping all Python processes...
taskkill /F /IM python.exe 2>nul
echo ✓ All servers stopped
goto menu

endlocal
