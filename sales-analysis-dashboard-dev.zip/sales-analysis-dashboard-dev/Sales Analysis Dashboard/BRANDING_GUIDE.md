# 🎨 Company Branding & Customization Guide

## Overview
This guide explains how to customize the Sales Dashboard to match your company's branding.

---

## 1. Logo & Company Name

### Update Dashboard Title
Edit `frontend/index.html`:
```html
<!-- Line ~22 -->
<h1>Sales Analysis</h1>
<p>Dashboard & Analytics</p>

<!-- Change to your company: -->
<h1>Your Company Name</h1>
<p>Sales Intelligence Platform</p>
```

### Update Page Title (Browser Tab)
```html
<!-- Line ~5 -->
<title>Sales Analysis Dashboard - Professional Business Intelligence</title>

<!-- Change to: -->
<title>Your Company Sales Dashboard</title>
```

---

## 2. Color Scheme

### Update Primary Colors
Edit `frontend/css/style.css` (Lines 1-50):

```css
:root {
  /* Change these colors to match your brand */
  --primary-color: #2563eb;        /* Main brand color */
  --primary-hover: #1d4ed8;         /* Hover state */
  --secondary-color: #059669;       /* Secondary color */
  --accent-color: #7c3aed;          /* Accent/highlight */
  
  /* Example: Blue to Purple gradient */
  --primary-color: #6366f1;         /* Indigo */
  --primary-hover: #4f46e5;
  --secondary-color: #8b5cf6;       /* Violet */
  --accent-color: #a855f7;          /* Purple */
}
```

### Gradient Customization
Edit `frontend/css/professional.css`:
```css
--gradient-primary: linear-gradient(135deg, #your-color-1 0%, #your-color-2 100%);
--gradient-accent: linear-gradient(135deg, #color-3 0%, #color-4 100%);
--gradient-success: linear-gradient(135deg, #color-5 0%, #color-6 100%);
```

---

## 3. Sidebar Customization

### Change Sidebar Title & Icon
Edit `frontend/index.html` (Line ~75):
```html
<div class="sidebar-header">
    <h2>📊 Sales Dashboard</h2>
</div>

<!-- Change to: -->
<h2>🏢 Your Company</h2>
```

### Customize Navigation Icons
```html
<a href="#" class="nav-link active" data-section="dashboard">
    <span class="icon">📊</span>  <!-- Change emoji -->
    <span>Dashboard</span>            <!-- Change label -->
</a>
```

Available emoji icons:
- 📊 Dashboard
- 💼 Sales
- 📈 Reports
- 👥 Customers
- 🤝 Providers
- ⚙️ Settings
- 👤 Profile
- 📱 Mobile

---

## 4. Font Customization

### Change From Inter to Another Font
Edit `frontend/index.html`:
```html
<!-- Current -->
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">

<!-- Change to other Google Fonts: -->
<!-- Roboto -->
<link href="https://fonts.googleapis.com/css2?family=Roboto:wght@300;400;500;700&display=swap" rel="stylesheet">

<!-- Poppins (Modern) -->
<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">

<!-- Open Sans -->
<link href="https://fonts.googleapis.com/css2?family=Open+Sans:wght@300;400;500;700&display=swap" rel="stylesheet">
```

Then update CSS:
```css
html, body {
    font-family: 'Poppins', -apple-system, BlinkMacSystemFont, sans-serif;  /* Change font name */
}
```

---

## 5. Customize Dashboard Cards

### Change KPI Card Labels
Edit `frontend/index.html` (Lines ~150-170):
```html
<div class="kpi-card">
    <h3>Total Sales</h3>        <!-- Change label -->
    <p id="total-sales">$0</p>
    <span class="kpi-trend positive" id="sales-trend">↗ 12%</span>
</div>
```

### Available Labels:
- Total Sales / Revenue / Income
- Total Orders / Transactions / Deals
- Avg Order Value / Average Deal Size / AOV
- Growth Rate / Quarter Growth / YoY Growth

---

## 6. Header & Footer

### Add Company Logo
Edit `frontend/index.html` - Add before company name:
```html
<img src="your-logo.png" alt="Company Logo" style="height: 40px; margin-bottom: 16px;">
<h1>Your Company Name</h1>
```

### Add Footer
Edit `frontend/index.html` - Add before closing body tag:
```html
<footer class="dashboard-footer">
    <p>&copy; 2026 Your Company Name. All rights reserved.</p>
    <p><a href="#">Privacy Policy</a> | <a href="#">Terms of Service</a> | <a href="#">Contact Us</a></p>
</footer>
```

## 7. Quick Color Palettes

### Professional Blue
```css
--primary-color: #0066cc;
--primary-hover: #0052a3;
--secondary-color: #00264d;
```

### Modern Purple
```css
--primary-color: #7c3aed;
--primary-hover: #6d28d9;
--secondary-color: #4c1d95;
```

### Vibrant Orange
```css
--primary-color: #ff6b35;
--primary-hover: #e55100;
--secondary-color: #004e89;
```

### Corporate Dark
```css
--primary-color: #1a365d;
--primary-hover: #132852;
--secondary-color: #2d3748;
```

### Modern Green
```css
--primary-color: #059669;
--primary-hover: #047857;
--secondary-color: #065f46;
```

---

## 8. Dashboard Sections

### Add Your Own Sections
Edit `frontend/index.html` - Add new nav link:
```html
<a href="#" class="nav-link" data-section="inventory">
    <span class="icon">📦</span>
    <span>Inventory</span>
</a>
```

Then add corresponding HTML section:
```html
<div id="inventory-section" class="content-section">
    <!-- Your content here -->
</div>
```

And add CSS for the new section in `professional.css`.

---

## 9. Table Customization

### Change Table Column Names
Edit `frontend/index.html` (Lines ~240-280):
```html
<table id="sales-table">
    <thead>
        <tr>
            <th>ID</th>
            <th>Product</th>
            <th>Category</th>
            <th>Amount</th>
            <!-- Add more columns as needed -->
        </tr>
    </thead>
</table>
```

---

## 10. Form Customization

### Change Form Field Labels
Edit `frontend/index.html` (Lines ~230-260):
```html
<div class="form-group">
    <label for="form-product-name">Product Name</label>
    <input type="text" id="form-product-name" placeholder="Product name" required>
</div>

<!-- Change to: -->
<div class="form-group">
    <label for="form-product-name">Item Name</label>
    <input type="text" id="form-product-name" placeholder="Enter item name" required>
</div>
```

---

## 11. Authentication Customization

### Change Login Page Title
Edit `frontend/index.html` (Line ~30):
```html
<div class="auth-header">
    <h1>Sales Analysis</h1>

    <!-- Change to: -->
    <h1>Welcome to Your Company</h1>
    <p>Sign in to your sales dashboard</p>
</div>
```

---

## 12. Chart Customization

### Customize Chart Colors
Edit `frontend/js/dashboard.js` - Find chart creation functions:
```javascript
// Example:
const revenueChart = new Chart(ctx, {
    type: 'line',
    data: {
        labels: [...],
        datasets: [{
            label: 'Revenue',
            data: [...],
            borderColor: '#2563eb',      // Change color
            backgroundColor: 'rgba(37, 99, 235, 0.1)',
        }]
    }
});
```

### Common Chart Colors:
- Blue: `#2563eb`
- Green: `#059669`
- Red: `#dc2626`
- Orange: `#f97316`
- Purple: `#7c3aed`

---

## 13. Mobile Responsiveness

### Test on Mobile
Your dashboard is already responsive! Test by:
1. Open in browser
2. Press F12 (DevTools)
3. Click device toggle (mobile icon)
4. Test different screen sizes

### Customize Mobile Breakpoints
Edit `professional.css` (Lines ~400-450):
```css
@media (max-width: 768px) {
    /* Mobile styles */
}

@media (max-width: 1200px) {
    /* Tablet styles */
}
```

---

## 14. Complete Example: Apple-Inspired Theme

```css
:root {
  --primary-color: #000000;
  --primary-hover: #1a1a1a;
  --secondary-color: #555555;
  --accent-color: #a2aaad;
  
  --bg-primary: #ffffff;
  --bg-secondary: #f5f5f5;
  
  --text-primary: #000000;
  --text-secondary: #555555;
}

html, body {
  font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
}
```

---

## 15. Before/After Examples

### Before (Default)
- Company: "Sales Analysis"
- Color: Blue (#2563eb)
- Font: Inter
- Accent: Purple

### After (Customized)
- Company: "TechCorp Solutions"
- Color: Dark Navy (#1a365d)
- Font: Poppins
- Accent: Electric Blue (#0066ff)

---

## Testing Your Changes

1. **Make CSS changes** - refresh browser (Ctrl+F5)
2. **Make HTML changes** - save and refresh
3. **Check different browsers** - Safari, Chrome, Firefox
4. **Test mobile view** - DevTools → Toggle device toolbar
5. **Dark mode** - Click 🌙 button to verify consistency

---

## Getting Help with Customization

### Where to Find Key Files

| Change | File | Location |
|--------|------|----------|
| Colors | `frontend/css/style.css` | Lines 1-50 |
| Layout | `frontend/css/professional.css` | Full file |
| Content | `frontend/index.html` | Lines 1-500 |
| Charts | `frontend/js/dashboard.js` | Throughout |
| Logo | `frontend/` | Add new image file |

---

## Pro Tips

1. **Use color picker**: https://htmlcolorcodes.com
2. **Font options**: https://fonts.google.com
3. **Test contrast**: https://webaim.org/resources/contrastchecker/
4. **Responsive testing**: https://responsively.app/
5. **Keep brand consistency**: Use same colors throughout
6. **Document changes**: Keep a changelog of customizations

---

**Your dashboard is now ready to be personalized! 🎨**
