#!/bin/bash
# ====================================================================
# Sales Dashboard - One-Click Deployment Script (Linux/Mac)
# ====================================================================

set -e

PROJECT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$PROJECT_DIR"

echo ""
echo "========================================"
echo "  Sales Dashboard - Deployment Tool"
echo "========================================"
echo ""

# Function to display menu
show_menu() {
    echo ""
    echo "Select an option:"
    echo "1. Development Setup (Backend + Frontend)"
    echo "2. Production Setup (Gunicorn)"
    echo "3. Install Dependencies"
    echo "4. Reset Database"
    echo "5. Health Check"
    echo "6. Stop All Servers"
    echo "7. Exit"
    echo ""
    read -p "Enter your choice (1-7): " choice
    
    case $choice in
        1) dev_setup ;;
        2) prod_setup ;;
        3) install_deps ;;
        4) reset_db ;;
        5) health_check ;;
        6) stop_servers ;;
        7) exit 0 ;;
        *) echo "Invalid choice. Please try again."; show_menu ;;
    esac
}

# Install dependencies
install_deps() {
    echo ""
    echo "Installing Python dependencies..."
    cd backend
    pip install -r requirements.txt
    cd ..
    echo "✓ Dependencies installed successfully"
    show_menu
}

# Development setup
dev_setup() {
    echo ""
    echo "Starting Development Environment..."
    echo ""
    
    # Kill existing processes
    echo "Stopping any existing processes..."
    pkill -f "python.*app.py" || true
    pkill -f "http.server" || true
    
    echo ""
    echo "Starting Flask Backend Server (Port 5000)..."
    cd backend
    python app.py &
    BACKEND_PID=$!
    cd ..
    
    sleep 3
    
    echo ""
    echo "Starting Frontend Server (Port 8080)..."
    cd frontend
    python -m http.server 8080 &
    FRONTEND_PID=$!
    cd ..
    
    echo ""
    echo "========================================"
    echo "✓ Development environment started!"
    echo ""
    echo "Access your application at:"
    echo "  Frontend: http://localhost:8080/index.html"
    echo "  Backend:  http://localhost:5000"
    echo "  Health:   http://localhost:5000/health"
    echo ""
    echo "PIDs: Backend=$BACKEND_PID, Frontend=$FRONTEND_PID"
    echo ""
    echo "Press Ctrl+C to stop servers..."
    wait
}

# Production setup
prod_setup() {
    echo ""
    echo "Production Setup - Installing Gunicorn..."
    pip install gunicorn
    
    echo ""
    echo "Starting Production Server (Gunicorn - Port 5000)..."
    cd backend
    gunicorn -w 4 -b 0.0.0.0:5000 --access-logfile - --error-logfile - app:app &
    PROD_PID=$!
    cd ..
    
    echo ""
    echo "✓ Production server started with Gunicorn (4 workers)"
    echo "Frontend should be served by Nginx or another web server"
    echo ""
    echo "Access backend at: http://localhost:5000"
    echo "PID: $PROD_PID"
    show_menu
}

# Reset database
reset_db() {
    echo ""
    read -p "WARNING: This will delete all data! Are you sure? (yes/no): " confirm
    
    if [ "$confirm" != "yes" ]; then
        echo "Reset cancelled"
        show_menu
        return
    fi
    
    echo "Resetting database..."
    cd backend
    rm -f sales.db
    echo "Creating fresh database..."
    python -c "from app import app, db; app.app_context().push(); db.create_all(); print('Database reset successfully')"
    cd ..
    
    echo "✓ Database reset complete"
    show_menu
}

# Health check
health_check() {
    echo ""
    echo "Checking backend health..."
    if command -v curl &> /dev/null; then
        curl -s http://localhost:5000/health | python -m json.tool || echo "✗ Backend is not responding"
    else
        echo "curl not found. Install curl to check health."
    fi
    show_menu
}

# Stop servers
stop_servers() {
    echo ""
    echo "Stopping all Python processes..."
    pkill -f python || true
    echo "✓ All servers stopped"
    show_menu
}

# Main
if [ ! -d "backend" ]; then
    echo "ERROR: Please run this script from the project root directory"
    exit 1
fi

show_menu
