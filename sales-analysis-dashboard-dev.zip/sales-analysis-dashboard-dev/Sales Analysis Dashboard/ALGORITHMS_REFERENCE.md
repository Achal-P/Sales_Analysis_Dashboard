# 🔍 ESDS Sales Dashboard - Algorithms Reference Guide

**Date:** April 8, 2026  
**Version:** 1.0  
**For:** Developers | Computer Science Students | Technical Reference

---

## 📖 TABLE OF CONTENTS

1. [Algorithms Overview](#1-algorithms-overview)
2. [Data Aggregation](#2-data-aggregation-algorithms)
3. [Sorting Algorithm](#3-sorting-algorithm)
4. [Filtering Algorithm](#4-filtering-algorithm)
5. [Searching Algorithm](#5-searching-algorithm)
6. [Grouping & Hash-Based Aggregation](#6-grouping--hash-based-aggregation)
7. [Authentication & Token Verification](#7-authentication--token-verification)
8. [Role-Based Access Control](#8-role-based-access-control-rbac)
9. [Data Validation](#9-data-validation-algorithm)
10. [Chart Rendering](#10-chart-rendering-algorithm)
11. [Firestore Query Optimization](#11-firestore-query-optimization)
12. [Encryption Algorithm](#12-encryption-algorithm)
13. [Caching & Memoization](#13-caching--memoization)
14. [Complexity Analysis](#14-algorithm-complexity-analysis)
15. [Real Code Examples](#15-real-code-examples-from-project)
16. [Performance Tips](#16-performance-optimization)
17. [Algorithm Flow Diagrams](#17-algorithm-flow-diagrams)
18. [Comparison Table](#18-summary-comparison-table)

---

## 1. ALGORITHMS OVERVIEW

### What Are Algorithms?
An **algorithm** is a step-by-step procedure to solve a problem or perform a computation.

### Why Algorithms Matter?
- **Efficiency**: Good algorithms run faster
- **Scalability**: Handle more users without slowing down
- **Reliability**: Proven methods work correctly
- **Performance**: Better algorithms = happier users

### Algorithms in This Project
This ESDS Sales Dashboard uses **practical algorithms** for:
- Calculating business metrics
- Storing/retrieving data efficiently
- Securing user information
- Controlling who sees what
- Rendering beautiful charts

---

## 2. DATA AGGREGATION ALGORITHMS

### Purpose
Calculate summary statistics from dataset (total, average, maximum, etc.)

### Used In
- Dashboard KPI cards
- Chart labels
- Report generation

### Algorithm: SUM

```javascript
// Algorithm: Linear Sum
// Time Complexity: O(n)
// Space Complexity: O(1)

function calculateTotalSales(sales) {
    let totalSales = 0;
    
    // Iterate through all sales
    for (let i = 0; i < sales.length; i++) {
        totalSales += sales[i].amount;  // Add each amount
    }
    
    return totalSales;
}

// Using JavaScript reduce (functional approach)
const totalSales = sales.reduce((sum, sale) => sum + sale.amount, 0);

// Example:
// Input: [{amount: 50000}, {amount: 30000}, {amount: 20000}]
// Output: 100000
```

### Algorithm: AVERAGE

```javascript
// Algorithm: Calculate Mean Average
// Time Complexity: O(n)
// Space Complexity: O(1)

function calculateAverageOrder(sales) {
    if (sales.length === 0) return 0;
    
    const totalSales = sales.reduce((sum, sale) => sum + sale.amount, 0);
    const averageOrder = totalSales / sales.length;
    
    return averageOrder;
}

// Example:
// Input: [{amount: 50000}, {amount: 30000}, {amount: 20000}]
// Output: 33333.33
```

### Algorithm: MAXIMUM

```javascript
// Algorithm: Find Maximum Value
// Time Complexity: O(n)
// Space Complexity: O(1)

function findTopSale(sales) {
    let maxAmount = sales[0].amount;
    
    for (let i = 1; i < sales.length; i++) {
        if (sales[i].amount > maxAmount) {
            maxAmount = sales[i].amount;
        }
    }
    
    return maxAmount;
}

// Using Math.max with spread operator
const maxSale = Math.max(...sales.map(s => s.amount));

// Example:
// Input: [{amount: 50000}, {amount: 30000}, {amount: 20000}]
// Output: 50000 (top product)
```

### Algorithm: COUNT

```javascript
// Algorithm: Count Elements
// Time Complexity: O(1)
// Space Complexity: O(1)

function countTotalItems(sales) {
    return sales.length;
}

// Example:
// Input: [{amount: 50000}, {amount: 30000}, {amount: 20000}]
// Output: 3
```

### Code in Project
**File:** `frontend/js/dashboard.js`

```javascript
// Real code from project
let totalSales = 0;
let totalItems = 0;
let maxSaleAmount = 0;

sales.forEach(sale => {
    totalSales += sale.amount;      // Aggregation
    totalItems++;                   // Counting
    if (sale.amount > maxSaleAmount) {
        maxSaleAmount = sale.amount; // Finding max
    }
});

const averageOrder = totalSales / totalItems;  // Average calculation
```

---

## 3. SORTING ALGORITHM

### Purpose
Arrange data in order (ascending or descending)

### Used In
- Top 5 products chart
- Recent transactions
- Sales rankings

### Algorithm: Comparison-Based Sorting (QuickSort/MergeSort)

```javascript
// Algorithm: Sort by Amount (Descending)
// Time Complexity: O(n log n)
// Space Complexity: O(log n) to O(n)

function sortSalesByAmount(sales) {
    // JavaScript's sort() uses QuickSort or MergeSort
    return sales.sort((a, b) => {
        return b.amount - a.amount;  // Descending
    });
}

// Step-by-step example:
// Input: [
//   {product: 'Laptop', amount: 50000},
//   {product: 'Phone', amount: 30000},
//   {product: 'Monitor', amount: 15000}
// ]

// After sorting (descending):
// Output: [
//   {product: 'Laptop', amount: 50000},
//   {product: 'Phone', amount: 30000},
//   {product: 'Monitor', amount: 15000}
// ]
```

### Top N Elements (Using Sorting)

```javascript
// Algorithm: Get Top 5 Products
// Time Complexity: O(n log n)
// Space Complexity: O(n)

function getTopProducts(sales, topN = 5) {
    // Step 1: Sort by amount (descending)
    const sorted = sales.sort((a, b) => b.amount - a.amount);
    
    // Step 2: Take first N elements
    return sorted.slice(0, topN);
}

// Example:
// Input: 100 sales records
// Output: Top 5 products with highest sales
```

### Sorting by Date (Recent First)

```javascript
// Algorithm: Sort by Date (Descending - Most Recent First)
// Time Complexity: O(n log n)
// Space Complexity: O(log n) to O(n)

function getRecentTransactions(sales) {
    return sales.sort((a, b) => {
        // Convert to Date objects and compare
        return new Date(b.date) - new Date(a.date);
    }).slice(0, 5);  // Get 5 most recent
}

// Example:
// Input: [
//   {date: '2026-04-01', amount: 50000},
//   {date: '2026-04-05', amount: 30000},
//   {date: '2026-04-03', amount: 20000}
// ]
// Output (most recent first):
// [
//   {date: '2026-04-05', amount: 30000},
//   {date: '2026-04-03', amount: 20000},
//   {date: '2026-04-01', amount: 50000}
// ]
```

### Code in Project
**File:** `frontend/js/dashboard.js`

```javascript
// Real code from project
// Sort products by sales amount
const topProducts = productSales.sort((a, b) => b.totalSales - a.totalSales)
                                .slice(0, 5);

// Sort transactions by date (most recent first)
const recentTransactions = sales.sort((a, b) => 
    new Date(b.date) - new Date(a.date)
).slice(0, 5);
```

---

## 4. FILTERING ALGORITHM

### Purpose
Select subset of data that match certain criteria

### Used In
- Sales table filters
- Category/Region filters
- Date range filters

### Algorithm: Linear Filter

```javascript
// Algorithm: Filter with Predicate
// Time Complexity: O(n)
// Space Complexity: O(m) where m = number of results

function filterSalesByCategory(sales, category) {
    const filtered = [];
    
    // Loop through all sales
    for (let i = 0; i < sales.length; i++) {
        // Check if matches criteria
        if (sales[i].category === category) {
            filtered.push(sales[i]);  // Include if matches
        }
    }
    
    return filtered;
}

// Using JavaScript filter() method
const electronicsSales = sales.filter(sale => sale.category === 'Electronics');

// Example:
// Input: [
//   {product: 'Laptop', category: 'Electronics'},
//   {product: 'Shirt', category: 'Clothing'},
//   {product: 'Phone', category: 'Electronics'}
// ]
// Output: [
//   {product: 'Laptop', category: 'Electronics'},
//   {product: 'Phone', category: 'Electronics'}
// ]
```

### Multiple Filters (AND Logic)

```javascript
// Algorithm: Filter with Multiple Conditions
// Time Complexity: O(n)
// Space Complexity: O(m)

function filterSalesByMultipleCriteria(sales, category, region, minAmount) {
    return sales.filter(sale => 
        sale.category === category &&        // Condition 1
        sale.region === region &&            // Condition 2
        sale.amount >= minAmount             // Condition 3
    );
}

// Example:
// Input: 100 sales records
// Output: Only 'Electronics' sales from 'North' region above ₹25,000
```

### Date Range Filter

```javascript
// Algorithm: Filter by Date Range
// Time Complexity: O(n)
// Space Complexity: O(m)

function filterSalesByDateRange(sales, startDate, endDate) {
    const start = new Date(startDate);
    const end = new Date(endDate);
    
    return sales.filter(sale => {
        const saleDate = new Date(sale.date);
        return saleDate >= start && saleDate <= end;
    });
}

// Example:
// Input: All sales, start: '2026-04-01', end: '2026-04-30'
// Output: Only April sales
```

### Code in Project
**File:** `frontend/index.html` (Filter UI) + `frontend/js/dashboard.js` (Logic)

```javascript
// Real code from project
// Filter sales by category
const filteredSales = sales.filter(sale => sale.category === selectedCategory);

// Filter sales by region
const regionalSales = sales.filter(sale => sale.region === selectedRegion);

// Display filtered results
displaySalesTable(filteredSales);
```

---

## 5. SEARCHING ALGORITHM

### Purpose
Find specific element in dataset

### Used In
- Customer search
- Product search
- Order lookup

### Algorithm: Linear Search

```javascript
// Algorithm: Linear Search (Sequential Search)
// Time Complexity: O(n)
// Space Complexity: O(1)

function searchCustomer(customers, customerName) {
    // Check each customer one by one
    for (let i = 0; i < customers.length; i++) {
        if (customers[i].name === customerName) {
            return customers[i];  // Found!
        }
    }
    return null;  // Not found
}

// Using JavaScript find() method
const customer = customers.find(c => c.name === customerName);

// Example:
// Input: Search for "John Retailer"
// Output: {id: 'C-001', name: 'John Retailer', email: 'john@email', ...}
```

### Case-Insensitive Search

```javascript
// Algorithm: Case-Insensitive Linear Search
// Time Complexity: O(n)
// Space Complexity: O(1)

function searchProductCaseInsensitive(products, searchTerm) {
    const lowerSearchTerm = searchTerm.toLowerCase();
    
    return products.find(product =>
        product.name.toLowerCase().includes(lowerSearchTerm)
    );
}

// Example:
// Input: Search for "lAPTOP"
// Output: {id: 'P-001', name: 'Laptop', price: 50000}
```

### Code in Project
**File:** `frontend/js/dashboard.js`

```javascript
// Real code from project
function findOfferByName(salesData, productName) {
    return salesData.find(sale => sale.product === productName);
}

// Used when looking up specific product in dashboard
```

---

## 6. GROUPING & HASH-BASED AGGREGATION

### Purpose
Group data by category and calculate summary per group

### Used In
- Category chart (group by category)
- Region chart (group by region)
- Customer chart (group by customer)

### Algorithm: Hash Table Grouping

```javascript
// Algorithm: Group By Category Using Hash Table
// Time Complexity: O(n)
// Space Complexity: O(k) where k = number of unique categories

function groupSalesByCategory(sales) {
    const grouped = {};  // Hash table (JavaScript object)
    
    // Iterate through all sales
    sales.forEach(sale => {
        // If category not seen before, initialize
        if (!grouped[sale.category]) {
            grouped[sale.category] = 0;
        }
        
        // Add amount to category total
        grouped[sale.category] += sale.amount;
    });
    
    return grouped;
}

// Example:
// Input: [
//   {category: 'Electronics', amount: 50000},
//   {category: 'Clothing', amount: 500},
//   {category: 'Electronics', amount: 30000}
// ]

// Output:
// {
//   'Electronics': 80000,
//   'Clothing': 500
// }
```

### Grouping with Complex Objects

```javascript
// Algorithm: Group with Detailed Information
// Time Complexity: O(n)
// Space Complexity: O(k)

function groupWithDetails(sales) {
    const grouped = {};
    
    sales.forEach(sale => {
        if (!grouped[sale.region]) {
            grouped[sale.region] = {
                total: 0,
                count: 0,
                items: []
            };
        }
        
        grouped[sale.region].total += sale.amount;
        grouped[sale.region].count++;
        grouped[sale.region].items.push(sale);
    });
    
    return grouped;
}

// Output example:
// {
//   'North': {
//     total: 80000,
//     count: 3,
//     items: [sale1, sale2, sale3]
//   },
//   'South': {
//     total: 50000,
//     count: 2,
//     items: [sale4, sale5]
//   }
// }
```

### Code in Project
**File:** `frontend/js/dashboard.js`

```javascript
// Real code from project
// Group sales by category (for category chart)
const salesByCategory = {};
sales.forEach(sale => {
    if (!salesByCategory[sale.category]) {
        salesByCategory[sale.category] = 0;
    }
    salesByCategory[sale.category] += sale.amount;
});

// Group sales by region (for region chart)
const salesByRegion = {};
sales.forEach(sale => {
    if (!salesByRegion[sale.region]) {
        salesByRegion[sale.region] = 0;
    }
    salesByRegion[sale.region] += sale.amount;
});
```

---

## 7. AUTHENTICATION & TOKEN VERIFICATION

### Purpose
Verify user identity and maintain secure session

### Algorithm: JWT (JSON Web Token) Verification

```javascript
// Algorithm: Token-Based Authentication Flow
// Time Complexity: O(1)
// Space Complexity: O(1)

/*
Step 1: User Login
-----------------
User submits email + password
    ↓
Firebase validates credentials
    ↓
If valid: Generate JWT token
If invalid: Reject login

Firebase generates: header.payload.signature
Example: eyJhbGc.eyJpZCI6.SflKxw

Step 2: Token Storage
---------------------
Token stored in browser memory (volatile)
NOT stored in localStorage (security risk)

Step 3: Subsequent Requests
----------------------------
Every request to backend includes token

JavaScript code:
    const token = await user.getIdToken();
    fetch('/api/sales', {
        headers: { 'Authorization': token }
    });

Step 4: Backend Verification
-----------------------------
Flask receives token
    ↓
Decodes token signature using Firebase public key
    ↓
Verifies: Token not expired + Not tampered
    ↓
Extracts user ID from token
    ↓
Grants access if valid
*/

// Firebase handles this automatically
firebase.auth().onAuthStateChanged(user => {
    if (user) {
        // User is logged in
        const uid = user.uid;
        const token = user.getIdToken();
        // Can now access protected data
    } else {
        // User not logged in
        // Redirect to login page
    }
});
```

### JWT Structure

```
Header.Payload.Signature

Example decoded token:
{
  "header": {
    "alg": "RS256",
    "kid": "key_id"
  },
  "payload": {
    "iss": "firebase.google.com",
    "aud": "project-id",
    "auth_time": 1617312345,
    "user_id": "uid_abc123xyz",
    "sub": "uid_abc123xyz",
    "iat": 1617312345,
    "exp": 1617316000
  },
  "signature": "HMAC_SHA256(header+payload, secret)"
}
```

### Code in Project
**File:** `frontend/js/auth.js`

```javascript
// Real code from project
firebase.auth().onAuthStateChanged(async (user) => {
    if (user) {
        const uid = user.uid;
        
        // Get token for subsequent requests
        const token = await user.getIdToken();
        
        // Load user role from Firestore
        loadUserRole();
        
        // Show dashboard
        document.getElementById('auth-container').style.display = 'none';
        document.getElementById('dashboard').style.display = 'block';
    }
});
```

---

## 8. ROLE-BASED ACCESS CONTROL (RBAC)

### Purpose
Determine what each user can see and do based on their role

### Algorithm: Permission Checking

```javascript
// Algorithm: Role-Based Access Control
// Time Complexity: O(1)
// Space Complexity: O(1)

const ROLE_PERMISSIONS = {
    'Customer': {
        canViewSales: true,
        canViewCustomers: true,
        canViewProviders: false,
        canAddSale: true,
        canAddCustomer: true,
        canAddProvider: false
    },
    'Provider': {
        canViewSales: true,
        canViewCustomers: false,
        canViewProviders: true,
        canAddSale: true,
        canAddCustomer: false,
        canAddProvider: true
    }
};

// Check if user has permission
function hasPermission(userRole, action) {
    return ROLE_PERMISSIONS[userRole]?.[action] || false;
}

// Example usage:
if (hasPermission(userRole, 'canViewCustomers')) {
    showCustomersTab();
}

// Example:
// Input: userRole = 'Customer', action = 'canViewCustomers'
// Output: true (allowed)

// Input: userRole = 'Provider', action = 'canViewCustomers'
// Output: false (not allowed)
```

### Conditional UI Rendering

```javascript
// Algorithm: Apply CSS Classes Based on Role
// Time Complexity: O(1)
// Space Complexity: O(1)

function applyRoleUI(role) {
    const body = document.body;
    
    // Remove all role classes
    body.classList.remove('customer-role', 'provider-role');
    
    // Add current role class
    if (role === 'Customer') {
        body.classList.add('customer-role');
    } else if (role === 'Provider') {
        body.classList.add('provider-role');
    }
}

// CSS-based conditional display:
// .customer-only { display: block; }
// .provider-role .customer-only { display: none; }
// 
// .provider-only { display: none; }
// .provider-role .provider-only { display: block; }
```

### Code in Project
**File:** `frontend/js/auth.js`

```javascript
// Real code from project
async function applyRoleUI() {
    const role = await getCurrentRole();
    
    const body = document.body;
    body.classList.remove('customer-role', 'provider-role');
    
    if (role === 'Customer') {
        body.classList.add('customer-role');
    } else if (role === 'Provider') {
        body.classList.add('provider-role');
    }
}

// File: frontend/css/professional.css
// .customer-only { display: block; }
// .provider-role .customer-only { display: none; }
```

---

## 9. DATA VALIDATION ALGORITHM

### Purpose
Check if data is correct format before saving

### Algorithm: Form Validation

```javascript
// Algorithm: Multi-Level Form Validation
// Time Complexity: O(1) - fixed number of checks
// Space Complexity: O(1)

function validateSaleForm(data) {
    // Check 1: Product name not empty
    if (!data.productName || data.productName.trim().length === 0) {
        return {
            valid: false,
            error: "Product name is required"
        };
    }
    
    // Check 2: Amount is valid number
    if (!data.amount || isNaN(data.amount) || data.amount <= 0) {
        return {
            valid: false,
            error: "Amount must be a positive number"
        };
    }
    
    // Check 3: Category selected
    if (!data.category || data.category.trim().length === 0) {
        return {
            valid: false,
            error: "Please select a category"
        };
    }
    
    // Check 4: Valid date
    if (!isValidDate(data.date)) {
        return {
            valid: false,
            error: "Invalid date format"
        };
    }
    
    // Check 5: Customer name not empty
    if (!data.customerName || data.customerName.trim().length === 0) {
        return {
            valid: false,
            error: "Customer name is required"
        };
    }
    
    // All checks passed
    return {
        valid: true,
        error: null
    };
}

// Helper function to check date
function isValidDate(dateString) {
    const date = new Date(dateString);
    return date instanceof Date && !isNaN(date);
}

// Usage:
const result = validateSaleForm({
    productName: "Laptop",
    amount: 50000,
    category: "Electronics",
    date: "2026-04-08",
    customerName: "John"
});

if (result.valid) {
    saveSale();
} else {
    showError(result.error);
}
```

### Email Validation

```javascript
// Algorithm: Email Format Validation
// Time Complexity: O(n) where n = length of email
// Space Complexity: O(1)

function isValidEmail(email) {
    // Regex pattern for email validation
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return emailRegex.test(email);
}

// Examples:
// isValidEmail("user@example.com") → true
// isValidEmail("invalid.email") → false
// isValidEmail("user@domain") → false
```

### Code in Project
**File:** `frontend/js/dashboard.js`

```javascript
// Real code from project
// Validation in submitSaleForm()
if (!formData.get('product')) {
    alert('Product name required');
    return;
}

if (!formData.get('amount') || formData.get('amount') <= 0) {
    alert('Amount must be positive');
    return;
}

// Only if all validations pass
console.log('Validation passed, saving to Firestore');
```

---

## 10. CHART RENDERING ALGORITHM

### Purpose
Convert raw data into visual representations

### Algorithm: Chart.js Data Normalization

```javascript
// Algorithm: Chart Rendering
// Time Complexity: O(n) for data processing + O(n) for rendering
// Space Complexity: O(n)

// Chart.js steps:
// 1. Receive raw data
// 2. Find min/max values
// 3. Calculate scale (axis units)
// 4. Normalize data to pixel coordinates
// 5. Draw on HTML5 Canvas

function createRevenueChart(salesData) {
    // Step 1: Process data
    const monthlyRevenue = {};
    salesData.forEach(sale => {
        const month = new Date(sale.date).toLocaleString('en-IN', { month: 'short' });
        monthlyRevenue[month] = (monthlyRevenue[month] || 0) + sale.amount;
    });
    
    // Step 2: Convert to chart format
    const labels = Object.keys(monthlyRevenue);
    const data = Object.values(monthlyRevenue);
    
    // Step 3: Create chart
    new Chart(ctx, {
        type: 'line',
        data: {
            labels: labels,      // X-axis labels
            datasets: [{
                label: 'Revenue (₹)',
                data: data,       // Y-axis data
                borderColor: '#1e40af',
                backgroundColor: 'rgba(30, 64, 175, 0.1)',
                tension: 0.4,
                fill: true
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: true,
            scales: {
                y: {
                    beginAtZero: true,
                    ticks: {
                        callback: function(value) {
                            return '₹' + value.toLocaleString('en-IN');
                        }
                    }
                }
            }
        }
    });
}

// Step-by-step data flow:
// Raw Sales Data
//     ↓
// Group by month (aggregation)
//     ↓
// Extract labels and values
//     ↓
// Chart.js calculates scale
//     ↓
// Normalize to pixel coordinates
//     ↓
// Draw on canvas
//     ↓
// Display to user
```

### Code in Project
**File:** `frontend/js/dashboard.js`

```javascript
// Real code from project
function createProductsChart() {
    // Get sales data grouped by product
    const products = {};
    
    sales.forEach(sale => {
        if (!products[sale.product]) {
            products[sale.product] = 0;
        }
        products[sale.product] += sale.amount;
    });
    
    // Sort and get top 5
    const sorted = Object.entries(products)
        .sort((a, b) => b[1] - a[1])
        .slice(0, 5);
    
    // Prepare for Chart.js
    const labels = sorted.map(p => p[0]);
    const data = sorted.map(p => p[1]);
    
    // Create chart
    new Chart(productCtx, {
        type: 'bar',
        data: {
            labels: labels,
            datasets: [{
                label: 'Sales (₹)',
                data: data,
                backgroundColor: '#1e40af'
            }]
        }
    });
}
```

---

## 11. FIRESTORE QUERY OPTIMIZATION

### Purpose
Efficiently retrieve data from cloud database

### Algorithm: B-Tree Index Lookup

```javascript
// Algorithm: Firestore Index-Based Query
// Time Complexity: O(log n) for index lookup
// Space Complexity: O(log n)

/*
Firestore Query Plan:
1. Frontend sends query
2. Firestore finds appropriate index
3. Uses B-tree search to locate matching documents
4. Returns matching documents

Query Example:
*/

async function getRecentSales() {
    // This query is optimized with Firestore indexes
    const query = db.collection('users')
                     .doc(currentUserUID)
                     .collection('sales')
                     .where('date', '>=', startDate)      // Filtered with index
                     .where('date', '<=', endDate)        // Filtered with index
                     .orderBy('date', 'desc')             // Sorted with index
                     .limit(10);                          // Pagination
    
    const snapshot = await query.get();
    return snapshot.docs.map(doc => doc.data());
}

// Execution Plan:
// 1. Firestore reads index for 'users/{uid}/sales'
// 2. Binary search on date field (B-tree): O(log n)
// 3. Returns matching documents
// 4. Apply sorting: O(m log m) where m = result count
// 5. Apply limit: O(1)
// 6. Total: O(log n + m log m)
```

### Firestore Index Structure

```
Firestore Internal Structure:
┌─────────────────────────┐
│   B-Tree Index          │
├─────────────────────────┤
│   Field: 'date'         │
├─────────────────────────┤
│   ├─ 2026-04-01 → [doc1]│
│   ├─ 2026-04-03 → [doc2]│
│   ├─ 2026-04-05 → [doc3]│
│   ├─ 2026-04-07 → [doc4]│
│   └─ 2026-04-09 → [doc5]│
└─────────────────────────┘

Query: date >= '2026-04-03' && date <= '2026-04-07'
Binary search finds: 2026-04-03
Range scan returns: [doc2, doc3, doc4]
```

### Code in Project
**File:** `frontend/js/dashboard.js`

```javascript
// Real code from project
async function loadSales() {
    try {
        const user = firebase.auth().currentUser;
        
        // Firestore query with automatic indexing
        const query = db.collection('users')
                       .doc(user.uid)
                       .collection('sales');
        
        const snapshot = await query.get();
        
        return snapshot.docs.map(doc => ({
            id: doc.id,
            ...doc.data()
        }));
    } catch (error) {
        console.error('Error loading sales:', error);
    }
}
```

---

## 12. ENCRYPTION ALGORITHM

### Purpose
Protect data security during storage and transmission

### Algorithms Used

```
1. PASSWORD HASHING: bcrypt
   ├─ Algorithm: Key derivation function (KDF)
   ├─ Iterations: 2^10 = 1024 rounds
   ├─ Time Complexity: O(2^cost) - intentionally slow
   ├─ Purpose: Makes brute force attacks impractical
   └─ Usage: Firebase Auth

2. DATA ENCRYPTION: AES-256
   ├─ Algorithm: Advanced Encryption Standard
   ├─ Key Size: 256 bits
   ├─ Mode: GCM (Galois/Counter Mode)
   ├─ Time Complexity: O(n) where n = data size
   └─ Usage: Firestore at rest
   
3. TRANSPORT ENCRYPTION: TLS 1.2+
   ├─ Algorithm: RSA key exchange + AES encryption
   ├─ Purpose: Encrypt data in transit
   └─ Used: All network communications

4. JWT SIGNING: HMAC-SHA256
   ├─ Algorithm: Hash-based Message Authentication Code
   ├─ Digest Size: 256 bits
   └─ Purpose: Verify token authenticity
```

### bcrypt Password Hashing

```javascript
// Algorithm: bcrypt Password Hashing
// Firebase handles this automatically

/*
Step 1: User enters password
Step 2: Firebase generates random salt
Step 3: Hash = bcrypt(password, salt, rounds=10)
Step 4: Store hash in database (NOT password)

Example:
Input password: "myPassword123"
Generated salt: "$2b$10$YourSaltHere"
Result hash: "$2b$10$YourSaltHereHashedResultHere"

Verification:
When user logs in:
1. User enters password: "myPassword123"
2. Retrieve stored hash: "$2b$10$..."
3. Hash input: bcrypt("myPassword123", stored_hash)
4. Compare hashes
5. If match: Login success
   If no match: Login failed
*/

// Time to compute one bcrypt hash: ~100ms
// Makes brute force infeasible:
// 10,000 passwords per second = 233 days to try 200 million passwords
```

### AES-256 Data Encryption

```
Algorithm: AES-256-GCM
├─ Key: 256 bits (32 bytes)
├─ IV (Initialization Vector): 96 bits (12 bytes) - random
├─ Additional Authenticated Data (AAD): Metadata
└─ Authentication Tag: 128 bits (16 bytes)

Encryption Process:
Plain Text Input
    ↓
Generate random IV
    ↓
AES-256 encrypt with key + IV
    ↓
Generate authentication tag
    ↓
Cipher Text = IV + Encrypted Data + Auth Tag
    ↓
Store in database

Decryption Process:
Cipher Text from database
    ↓
Extract IV
    ↓
AES-256 decrypt with key + IV
    ↓
Verify authentication tag
    ↓
Plain Text Output
```

### Code in Project
**File:** `backend/app.py`

```python
# Real code from project
# Flask handles HTTPS/TLS automatically
# Firestore encryption handled by Google

from flask import Flask
from flask_cors import CORS

app = Flask(__name__)
CORS(app)  # Enable secure communication

# All responses include security headers:
@app.after_request
def set_security_headers(response):
    response.headers['X-Content-Type-Options'] = 'nosniff'
    response.headers['X-Frame-Options'] = 'DENY'
    response.headers['X-XSS-Protection'] = '1; mode=block'
    return response
```

---

## 13. CACHING & MEMOIZATION

### Purpose
Store previously calculated results to avoid redundant computation

### Algorithm: Memoization

```javascript
// Algorithm: Memoization (Function Result Caching)
// Time Complexity: O(1) for cached results, O(function) for first call
// Space Complexity: O(n) where n = number of cached results

// Without caching - Database query every time
async function getUserRoleUncached() {
    return await db.collection('users').doc(uid).get();
    // Result: ~100-200ms network delay every call
}

// With caching - Store in memory
let userRoleCache = null;

async function getUserRoleCached() {
    if (userRoleCache) {
        return userRoleCache;  // Return cached result - O(1)
    }
    
    // First time: fetch from database
    userRoleCache = await db.collection('users').doc(uid).get();
    return userRoleCache;
    // Subsequent calls: return in O(1) time
}

// Usage difference:
// First call: 150ms (database lookup)
// Second call: 0.01ms (cache lookup)
// Speedup: 15,000x faster!
```

### Simple Cache Implementation

```javascript
// Algorithm: Simple Cache with Expiration
// Time Complexity: O(1)
// Space Complexity: O(n)

class SimpleCache {
    constructor(ttl = 60000) {  // 60 seconds default
        this.cache = {};
        this.ttl = ttl;
    }
    
    set(key, value) {
        this.cache[key] = {
            value: value,
            timestamp: Date.now()
        };
    }
    
    get(key) {
        if (!this.cache[key]) {
            return null;  // Not found
        }
        
        const item = this.cache[key];
        const age = Date.now() - item.timestamp;
        
        if (age > this.ttl) {
            delete this.cache[key];  // Expired
            return null;
        }
        
        return item.value;  // Valid
    }
}

// Usage:
const cache = new SimpleCache(60000);  // 1 minute TTL

// Store value
cache.set('userRole', 'Customer');

// Later: retrieve value
const role = cache.get('userRole');  // Returns 'Customer'

// After 60 seconds: retrieve again
const roleAfter = cache.get('userRole');  // Returns null (expired)
```

### Code in Project
**File:** `frontend/js/auth.js`

```javascript
// Real code from project
// Cache user role to avoid repeated Firestore queries

let cachedUserRole = null;

async function getCurrentRole() {
    if (cachedUserRole) {
        return cachedUserRole;  // Return cached value
    }
    
    // First time or cache empty
    const user = firebase.auth().currentUser;
    const doc = await db.collection('users').doc(user.uid).get();
    cachedUserRole = doc.data()?.role || 'Customer';
    
    return cachedUserRole;
}

// Benefit: First dashboard load fetches role from DB (150ms)
// Subsequent role checks instant (0.01ms)
```

---

## 14. ALGORITHM COMPLEXITY ANALYSIS

### Big O Notation Explanation

```
O(1) - Constant
├─ Time doesn't change with input size
├─ Example: Array access arr[5]
└─ Very fast: 1 microsecond

O(log n) - Logarithmic
├─ Time grows logarithmically
├─ Example: Binary search
├─ Halves problem size each step
└─ Fast: ~10 microseconds for 1 million items

O(n) - Linear
├─ Time proportional to input size
├─ Example: Iterate through array
├─ Moderate: ~1 millisecond for 1 million items

O(n log n) - Linearithmic
├─ Time grows with n * log(n)
├─ Example: Sorting (QuickSort, MergeSort)
├─ OK: ~10 milliseconds for 1 million items

O(n²) - Quadratic
├─ Time proportional to input squared
├─ Example: Nested loops
├─ Slow: ~1000 milliseconds for 1 million items
└─ Avoid when possible!
```

### Project Algorithms Comparison

| Operation | Algorithm | Time | Space | Category | Used For |
|-----------|-----------|------|-------|----------|----------|
| Sum sales | Aggregation | O(n) | O(1) | Linear | Total KPI |
| Average | Aggregation | O(n) | O(1) | Linear | Avg order KPI |
| Top 5 products | Sorting | O(n log n) | O(n) | Linearithmic | Top Products chart |
| Filter by category | Filter | O(n) | O(m) | Linear | Sales table filter |
| Search product | Linear search | O(n) | O(1) | Linear | Product lookup |
| Group by region | Hash grouping | O(n) | O(k) | Linear | Region chart |
| Get recent 5 | Filter + Sort | O(n log n) | O(n) | Linearithmic | Recent transactions |
| Verify JWT token | Hash check | O(1) | O(1) | Constant | Auth verification |
| Check role permission | Lookup | O(1) | O(1) | Constant | RBAC |
| Validate form | Checks | O(1) | O(1) | Constant | Form validation |
| Firestore query | B-tree lookup | O(log n) | O(log n) | Logarithmic | Database query |
| Password hash | bcrypt | O(1)* | O(1) | Constant | Login |
| Cache lookup | Hash table | O(1) | O(1) | Constant | Role caching |

*bcrypt is intentionally slow: ~100ms for security

### Visual Comparison

```
Time taken for 1,000,000 items:

O(1)       ████ 0.001ms
O(log n)   ████████ 0.02ms
O(n)       ███████████████████████████████ 1ms
O(n log n) ████████████████████████████████████████████████ 20ms
O(n²)      [off the chart - would take 16 minutes!]
```

---

## 15. REAL CODE EXAMPLES FROM PROJECT

### Example 1: Dashboard KPI Calculation

**File:** `frontend/js/dashboard.js`

```javascript
// Real code: Calculate all dashboard metrics

function updateDashboard() {
    // Aggregation Algorithm: O(n)
    let totalRevenue = 0;
    let totalItems = 0;
    let maxSaleAmount = 0;
    let topProduct = "";
    
    sales.forEach(sale => {
        totalRevenue += sale.amount;        // SUM
        totalItems++;                       // COUNT
        
        if (sale.amount > maxSaleAmount) {  // MAX
            maxSaleAmount = sale.amount;
            topProduct = sale.product;
        }
    });
    
    // Averaging Algorithm: O(1)
    const averageOrder = totalRevenue / totalItems;
    
    // Display with currency formatting
    animateValue('totalRevenue', totalRevenue, '₹');
    animateValue('averageOrder', averageOrder, '₹');
    animateValue('topProduct', topProduct, '');
    animateValue('totalItems', totalItems, '');
}
```

### Example 2: Top Products Chart

**File:** `frontend/js/dashboard.js`

```javascript
// Real code: Create Top Products chart

function createProductsChart() {
    // Step 1: Group and aggregate - O(n)
    const productSales = {};
    
    sales.forEach(sale => {
        if (!productSales[sale.product]) {
            productSales[sale.product] = 0;
        }
        productSales[sale.product] += sale.amount;
    });
    
    // Step 2: Sort and get top 5 - O(n log n)
    const topCrops = Object.entries(productSales)
        .sort((a, b) => b[1] - a[1])
        .slice(0, 5);
    
    // Step 3: Extract labels and data - O(m) where m = 5
    const labels = topCrops.map(p => p[0]);
    const data = topCrops.map(p => p[1]);
    
    // Step 4: Render chart - O(m)
    new Chart(productCtx, {
        type: 'bar',
        data: {
            labels: labels,
            datasets: [{
                label: 'Sales (₹)',
                data: data,
                backgroundColor: '#1e40af'
            }]
        }
    });
}
```

### Example 3: Form Validation

**File:** `frontend/js/dashboard.js`

```javascript
// Real code: Validate sale form before submission

async function submitSaleForm(event) {
    event.preventDefault();
    
    const formData = new FormData(event.target);
    
    // Validation - O(1)
    if (!formData.get('product')) {
        alert('Product name required');
        console.log('Validation failed: product name');
        return;
    }
    
    if (!formData.get('amount') || parseFloat(formData.get('amount')) <= 0) {
        alert('Amount must be positive');
        console.log('Validation failed: amount');
        return;
    }
    
    if (!formData.get('category')) {
        alert('Category required');
        console.log('Validation failed: category');
        return;
    }
    
    // All validations passed - save to Firestore
    try {
        const user = firebase.auth().currentUser;
        
        // Database write
        await db.collection('users')
               .doc(user.uid)
               .collection('sales')
               .add({
                   product: formData.get('product'),
                   category: formData.get('category'),
                   amount: parseFloat(formData.get('amount')),
                   customerName: formData.get('customerName'),
                   region: formData.get('region'),
                   date: formData.get('date')
               });
        
        alert('Sale added successfully!');
        event.target.reset();
        loadSales();  // Refresh dashboard
        
    } catch (error) {
        console.error('Error adding sale:', error);
        alert('Error: ' + error.message);
    }
}
```

---

## 16. PERFORMANCE OPTIMIZATION

### Tips for Faster Algorithms

```javascript
// 1. USE APPROPRIATE DATA STRUCTURES
// ❌ Bad: Filter array repeatedly
const filtered1 = sales.filter(s => s.category === 'Electronics');
const filtered2 = sales.filter(s => s.category === 'Electronics');  // Wasted!

// ✅ Good: Filter once, reuse
const electronicsSales = sales.filter(s => s.category === 'Electronics');
const total = electronicsSales.reduce((sum, s) => sum + s.amount, 0);

// 2. AVOID NESTED LOOPS (O(n²))
// ❌ Bad: Nested loops - O(n²)
for (let i = 0; i < sales.length; i++) {
    for (let j = 0; j < categories.length; j++) {
        if (sales[i].category === categories[j]) {
            // Process
        }
    }
}

// ✅ Good: Use Hash table - O(n)
const categorySet = new Set(categories);
for (let sale of sales) {
    if (categorySet.has(sale.category)) {
        // Process
    }
}

// 3. USE BUILT-IN METHODS (Optimized in C++)
// ❌ Bad: Manual implementation
let max = sales[0].amount;
for (let sale of sales) {
    if (sale.amount > max) max = sale.amount;
}

// ✅ Good: Use built-in
const max = Math.max(...sales.map(s => s.amount));

// 4. CACHE RESULTS
// ❌ Bad: Recalculate every time
function getTotal() {
    return sales.reduce((sum, s) => sum + s.amount, 0);  // Recalculated!
}

// ✅ Good: Calculate once, cache
let cachedTotal = null;
function getTotal() {
    if (!cachedTotal) {
        cachedTotal = sales.reduce((sum, s) => sum + s.amount, 0);
    }
    return cachedTotal;
}

// 5. LIMIT DATA SIZE
// ❌ Bad: Load all 1 million records
const allData = await db.collection('sales').get();

// ✅ Good: Load only what's needed
const recentData = await db.collection('sales')
                           .limit(100)
                           .get();

// 6. USE INDEXES
// ❌ Bad: Filter without index
const filtered = sales.filter(s => s.date >= startDate);  // Slow: O(n)

// ✅ Good: Use Firestore index
const snap = await db.collection('sales')
                     .where('date', '>=', startDate)
                     .get();  // Fast: O(log n)
```

---

## 17. ALGORITHM FLOW DIAGRAMS

### Complete User Login Flow

```
User enters credentials
        ↓
   Email + Password
        ↓
   Firebase Auth (Authentication Algorithm)
        ↓
   Hash password with bcrypt ───────────────────┐
        ↓                                       │
   Compare with stored hash                    │ Authentication
        ↓                                       │ Process
   ┌─────────────────┐                         │
   │ Match? (O(1))   │                         │
   └────┬──────┬────┘                          │
   ┌────▼───┬──┴─────┐                         │
   │  YES   │   NO   │                         │
   │        │        │                         │
   │        └────────┼──► Show Error           │
   │                 │    "Wrong Password"     │
   │                 └────────────────────────┘
   │
   └──► Generate JWT Token (O(1))
        ├─ Header: {alg: "RS256"}
        ├─ Payload: {uid, role, exp}
        └─ Signature: HMAC-SHA256
        
        ↓
   Store Token in Memory
        ↓
   Load User Role from Firestore (O(log n))
        ├─ Query: WHERE uid = currentUID
        └─ Result: "Customer" or "Provider"
        
        ↓
   Apply Role-Based UI (O(1))
        ├─ Add CSS class: body.customer-role
        └─ Show/Hide elements accordingly
        
        ↓
   Load Sales Data (O(log n))
        ├─ Query: WHERE userId = currentUID
        ├─ Firestore B-tree search
        └─ Return 10+ items
        
        ↓
   Calculate Dashboard Metrics (O(n))
        ├─ Total Revenue: SUM
        ├─ Average Order: AVG
        ├─ Top Product: MAX
        └─ Item Count: COUNT
        
        ↓
   Create Charts (O(n log n))
        ├─ Group by Category: O(n)
        ├─ Sort Top Products: O(n log n)
        ├─ Render Chart.js: O(n)
        └─ Display on Canvas
        
        ↓
   ✅ Dashboard Ready
```

### Add New Sale Flow

```
User fills form
        ↓
Clicks SAVE button
        ↓
JavaScript captures form data
        ↓
Validation Algorithm (O(1))
├─ Check product name not empty
├─ Check amount is positive number
├─ Check category selected
├─ Check date is valid
└─ Check customer name not empty
        │
        ├─ ❌ Invalid: Show error message
        │
        └─ ✅ Valid: Continue
                ↓
        Send POST request to Backend (O(1))
        ├─ Include JWT token
        └─ Include form data
                ↓
        Backend Receives (Flask)
                ├─ Verify JWT token (O(1))
                ├─ Extract userID from token
                └─ Check permissions (O(1))
                        │
                        ├─ ❌ Invalid: Return error
                        │
                        └─ ✅ Valid: Continue
                                ↓
                        Backend Validation (O(1))
                                ├─ Re-validate data
                                └─ Check against business rules
                                        │
                                        ├─ ❌ Invalid: Return error
                                        │
                                        └─ ✅ Valid: Continue
                                                ↓
                                        Save to Firestore (O(log n))
                                                ├─ Create document
                                                ├─ Store under /users/{uid}/sales/
                                                └─ Encryption: AES-256
                                                        │
                                                        ├─ ❌ Error: Return error message
                                                        │
                                                        └─ ✅ Success: Return success
                                                                ↓
                                        Frontend receives success
                                                ├─ Update table (O(n))
                                                ├─ Refresh charts (O(n log n))
                                                ├─ Update KPI cards (O(1))
                                                └─ Show confirmation message
                                                        ↓
                                                ✅ Sale Saved Successfully
```

---

## 18. SUMMARY COMPARISON TABLE

### Algorithm Characteristics

| # | Algorithm | Type | Time | Space | Stable | When to Use | Avoids |
|---|-----------|------|------|-------|--------|------------|---------|
| 1 | Sum/Aggregation | Math | O(n) | O(1) | N/A | Calculate totals | Repeated loops |
| 2 | Sorting | Comparison | O(n log n) | O(log n) | Yes | Top products, rankings | Nested loops |
| 3 | Filtering | Search | O(n) | O(m) | Yes | Find subset | Nested conditions |
| 4 | Linear Search | Search | O(n) | O(1) | N/A | Small datasets | Large datasets |
| 5 | Hash Grouping | Hash | O(n) | O(k) | No | Group by category | Repeated loops |
| 6 | JWT Token | Crypto | O(1) | O(1) | N/A | Authentication | Plain text passwords |
| 7 | RBAC Permission | Lookup | O(1) | O(1) | N/A | Role checks | Business logic in UI |
| 8 | Form Validation | Logic | O(1) | O(1) | N/A | Input checking | Invalid data |
| 9 | Chart Rendering | Graphics | O(n) | O(n) | No | Data visualization | Manual charts |
| 10 | B-Tree Index | Index | O(log n) | O(log n) | N/A | Database queries | Full table scans |
| 11 | bcrypt Hashing | Crypto | O(1)* | O(1) | N/A | Password storage | Plain text |
| 12 | Memoization | Cache | O(1) | O(n) | N/A | Repeated calls | Recalculation |

*Intentionally slow for security: ~100ms

---

## 🎓 KEY CONCEPTS FOR BEGINNERS

### What is Time Complexity?

```
Time Complexity = How long an algorithm takes
                  as the input size grows

O(1) - Very fast
O(log n) - Fast
O(n) - Medium
O(n log n) - Slower
O(n²) - Very slow (avoid!)
```

### What is Space Complexity?

```
Space Complexity = How much memory needed

O(1) - Constant (doesn't grow)
O(n) - Grows with input size
O(log n) - Grows logarithmically
```

### Why Learn Algorithms?

1. **Performance**: Good algorithms = faster apps
2. **Scalability**: Works with 1,000 or 1,000,000 users
3. **Cost**: Less CPU usage = lower cloud bills
4. **User Experience**: Faster response = happy users
5. **Interviews**: Tech companies ask algorithm questions

---

## 📚 FURTHER LEARNING

### Topics to Explore:

1. **Data Structures**
   - Arrays, Linked Lists, Trees, Graphs
   - Hash Tables, Heaps, Stacks, Queues

2. **Algorithm Design**
   - Greedy algorithms
   - Dynamic programming
   - Divide and conquer

3. **Database Optimization**
   - Index types (B-tree, Hash, Bitmap)
   - Query planning
   - Normalization

4. **Cryptography**
   - Encryption methods
   - Key management
   - Digital signatures

5. **Machine Learning**
   - Linear regression
   - Classification
   - Clustering

---

## ✅ CHECKLIST: UNDERSTANDING ALGORITHMS

- [ ] Know what algorithm is
- [ ] Understand Big O notation
- [ ] Can identify O(1), O(n), O(n log n) algorithms
- [ ] Know when to use sorting vs filtering
- [ ] Understand aggregation algorithms
- [ ] Know basic cryptography concepts
- [ ] Can read and understand code
- [ ] Can estimate time complexity
- [ ] Know when algorithm is needed
- [ ] Can optimize slow code

---

## 🔗 RELATED FILES IN PROJECT

- `COMPLETE_REFERENCE_GUIDE.md` - Complete project explanation
- `QUICK_START.md` - How to run the project
- `FIRESTORE_SECURITY_RULES.md` - Database security
- `frontend/js/dashboard.js` - Algorithm implementations
- `backend/app.py` - Server-side algorithms

---

## 📝 DOCUMENT INFO

- **Created**: April 8, 2026
- **For**: Developers, CS Students, Technical Reference
- **Difficulty**: Beginner to Intermediate
- **Topics**: 18 comprehensive sections
- **Code Examples**: 50+ real examples
- **Reading Time**: 60-90 minutes

---

**Happy Learning! 🚀**

Algorithms are the backbone of efficient software. Mastering them will make you a better developer!

---

*End of Algorithms Reference Document*
