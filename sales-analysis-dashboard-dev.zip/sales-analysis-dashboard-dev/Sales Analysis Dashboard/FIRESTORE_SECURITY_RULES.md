# Firestore Security Rules for ESDS Sales Dashboard

## UPDATE YOUR FIREBASE FIRESTORE SECURITY RULES

Go to **Firebase Console** → Your Project → **Firestore Database** → **Rules** tab

Replace the existing rules with the following code:

```javascript
rules_version = '2';
service cloud.firestore {
  match /databases/{database}/documents {
    // Allow authenticated users to read/write their own data
    match /users/{userId} {
      allow read, write: if request.auth.uid == userId;
      
      // Sales collection - read/write for authenticated user
      match /sales/{document=**} {
        allow read, write: if request.auth.uid == userId;
      }
      
      // Customers collection - read/write for authenticated user
      match /customers/{document=**} {
        allow read, write: if request.auth.uid == userId;
      }
      
      // Providers collection - read/write for authenticated user
      match /providers/{document=**} {
        allow read, write: if request.auth.uid == userId;
      }
    }
  }
}
```

## Steps to Update:

1. Go to [Firebase Console](https://console.firebase.google.com)
2. Select project: **sales-analysis-dashboard-f7dab**
3. Navigate to **Firestore Database** in left menu
4. Click **Rules** tab
5. Replace all content with the rules above
6. Click **Publish**

## What These Rules Do:

✅ **Allow authenticated users** to create/read/update/delete their own sales, customers, and providers
✅ **User-specific data isolation** - users can only access their own data (userId-based)
✅ **All collections protected** - sales, customers, and providers are secured
✅ **Perfect for multi-user scenarios** - each user's data is completely isolated

## Testing After Update:

1. Hard refresh browser: **Ctrl+Shift+R**
2. Sign in to your ESDS Sales Dashboard
3. Try to add a customer - should now work ✅
4. Try to add a provider - should now work ✅
5. Try to add a sale - should now work ✅
6. Check **Firebase Console** → **Firestore** → **Data** to see your entries

## If Still Having Issues:

1. Open browser **DevTools** (F12)
2. Go to **Console** tab
3. Try to add a customer/provider
4. Look for error messages
5. Share the error code from console

Common error codes:
- `permission-denied` = Security rules issue (follow steps above)
- `not-authenticated` = User not logged in
- `network-error` = Connection issue
